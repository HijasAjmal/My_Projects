<?php
if(session_id() == '' || !isset($_SESSION)){session_start();}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
        <link rel="icon" href="images/web.png">
        <title> SmartSP || Home </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
        <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
       
          <a class="navbar-brand" href="index.php">
<img border="1" alt="SmartSP" src="images/web.png" width="100" height="100">
</a>

    <div class="container">
  <div class="row">
    <div id="custom-search-input">
                            <div class="input-group col-md-8">
                                <input type="text" class="  search-query form-control" placeholder="Search" size="5">
                                <span class="input-group-btn">
                                    <button class="btn btn-danger" type="button">
                                        <span class=" glyphicon glyphicon-search"></span>
                                    </button>
                                </span>
                            </div>
                          </div>
                        </div>
        <ul class="nav navbar-nav">
            <li ><a href="#">Services |</a></li>
            <li ><a href="about.php">About-us |</a></li>
            <li ><a href="products.php">Products |</a></li>
           <li ><a href="contact.php">Contact-us</a></li>
         </ul>
         <ul class="nav navbar-nav navbar-right">
         <?php

          if(isset($_SESSION['email'])){
            echo '<li><a href="account.php"><span class="glyphicon glyphicon-user"></span>My Account |</a></li>';
            echo '<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Log Out</a></li>';
          }
          else{
            echo '<li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span>Login |</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span>Sign-Up</a></li>';
          }
          ?>

         
   
  </div>

</nav>




<style>
  .jumbotron {
      background-color:#BA4D0E;
      color: #fff;
      padding: 100px 25px;
  }
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #f4511e;
      font-size: 50px;
  }
  .logo {
      color: #f4511e;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
     background-image: none;
     color: #f4511e;
  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
  }
  .item span {
      font-style: normal;
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
  }
  </style>
</head>
<body>

<div class="jumbotron text-center">
  <h1>SmartSP</h1> 
  <p>make something different!</p> 
  <form method="POST" action="Subscribe.php"class="form-inline" >
    <div class="input-group">

     <div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input  type="email" class="form-control" name="email" placeholder="Email" size="35">
  </div>
      <div class="input-group-btn">
        <input type="submit" class="btn btn-danger" value="Subscribe">
        </a>
      </div>
    </div>
  </form>
</div>


  <b><h2 align="center">What our customers say</h2></b>
  <div id="myCarousel" class="carousel slide text-center" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <h4>"This company is the best. I am so happy with the result!"<br><span>Mahesh,kasaragod</span></h4>
      </div>
      <div class="item">
        <h4>"One word... WOW!!"<br><span>Dileep, Salesman</span></h4>
      </div>
      <div class="item">
        <h4>"Could I... BE any more happy with this company?"<br><span>Suraj, Actor</span></h4>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


<!-- Container (Services Section) -->
<div class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>What we offer</h4>
  <br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-shopping-cart logo-small"></span>
      <h4>Shared Purchase</h4>
      <p>Find your purchasing partner......</p>
      <p>SmartSP mainly aims to popularize combo offers by providing shared purchase scheme</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo-small"></span>
      <h4>Wholesale</h4>
      <p>Do you want goods in large quantities??</p>
      <p>acting as an agent or broker in buying merchandise for, or selling merchandise to, such persons or companies. </p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-stats logo-small"></span>
      <h4>Compare Product</h4>
      <p>Shopping online? A little research can save you a lot of money. Even when you know what you want</p>
      <p>It is worth checking one of the many available price and product comparison sites before making your purchase.</p>
    </div>
  </div>
  <br><br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-briefcase logo-small"></span>
      <h4>Part-Time Job</h4>
      <p>There is No limit or Target.You can work as much as you can.As this is a Part time Job.</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-piggy-bank logo-small"></span>
      <h4>Earnings</h4>
     <p>Get the best margins in the market.Service more, earn more!</p>
      <p>Set the discount you want to apply. Never lose a sale again!</p>
    </div>
    <div class="col-sm-4">
      <span class=" glyphicon glyphicon-headphones logo-small"></span>
      <h4 style="color:#303030;">24X7 Support</h4>
       <p>we offers you 24hr active customer service</p>
      <p>Email us at support@smartsp.com</p>
    </div>
  </div>
</div>

<!-- Container (Portfolio Section) -->
<div class="container-fluid text-center bg-grey">
  <h2>Our offices</h2><br>
  <b><h3>kerala region</h3></b>
  <div class="row text-center">
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="images/payyoli.jpg" alt="payyoli" width="400" height="300">
        <p><strong>Kozhikode</strong></p>
        <p>SmartSP solutions, payyoli</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="images/kanjhagad.jpg" alt="kanghagad" width="400" height="300">
        <p><strong>Kasaragod</strong></p>
        <p>SmartSP solutions, kanghagad</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="images/payyanur.jpg" alt="payyanur" width="400" height="300">
        <p><strong>Kannur</strong></p>
        <p>SmartSP solutions, payyanur</p>
      </div>
    </div>
  </div>


  <footer>
           <p style="text-align:center; font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</p>
        </footer>
</div>



      </div>
    </div>

  


</body>
</html>

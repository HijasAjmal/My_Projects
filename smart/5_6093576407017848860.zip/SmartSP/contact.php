<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();} for php 5.4 and above

if(session_id() == '' || !isset($_SESSION)){session_start();}


?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/web.png">
  <link rel="stylesheet" href="css/foundation.css" />
  <link rel="stylesheet" href="css/bootstrap.css" />
  <link rel="stylesheet" href="css/style.css" />
  <script src="js/vendor/modernizr.js"></script>
  <script src="js/bootstrap.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>SmartSP || Contact-Us</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

   <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
<img border="1" alt="SmartSP" src="images/web.png" width="100" height="100">
</a>

    <ul class="nav navbar-nav">
          <li><a href="about.php">About-us</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="cart.php">View Cart</a></li>
          
          <li><a href="contact.php">Contact</a></li>
          
      </ul>

    <ul class="nav navbar-nav navbar-right">
          
          <?php
    
          if(isset($_SESSION['email'])){
            echo '<li><a href="account.php">My Account</a></li>';
            echo '<li><a href="orders.php">My Orders</a></li>';
            echo '<li><a href="logout.php">Log Out</a></li>';
          }
          else{
            echo ' <li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
          }
          ?>
    </ul>
  </div>
</nav>

    <div class="row" style="margin-top:30px;">
      <div class="small-12">

        <p>Wanna get in touch.<br>Email us at <a href="mailto:support@smartsp.com">support@smartsp.com</a></p>

        <footer>
           <p style="text-align:center; font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</p>
        </footer>

      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>

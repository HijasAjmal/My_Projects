<?php

include 'config.php';
$email = $_POST["email"];

if($mysqli->query("INSERT INTO subscribe (email) VALUES('$email')")){
	echo 'Data inserted';
	echo '<br/>';
}

header ("location:index.php");

?>

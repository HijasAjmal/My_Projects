<?php

include 'config.php';

$name = $_POST["name"];
$email = $_POST["email"];
$mobile = $_POST["mobile"];
$password = $_POST["password"];

if($mysqli->query("INSERT INTO users (name, email,mobile, password) VALUES('$name','$email','$mobile', '$password')")){
	echo 'Data inserted';
	echo '<br/>';
}

header ("location:login.php");

?>

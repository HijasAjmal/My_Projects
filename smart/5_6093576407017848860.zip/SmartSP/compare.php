


<!DOCTYPE html>

<html lang="en">
<head><title>
    CompareRaja - Best Price Comparison and Online Shopping Site in India
</title><meta name="description" content="Compare Mobiles, Laptops, Tablets, ACs, Refrigerators online in India! Best prices, reviews, offers &amp; deals from Flipkart, Amazon, Snapdeal etc. at Compareraja." /><link rel="shortcut icon" href="https://www.compareprix.in/images/favicon.ico" type="image/x-icon" /><link rel="stylesheet" type="text/css" href="https://www.compareprix.in/stylesheet/header-footer18.css?v=0.56" /><link rel="dns-prefetch" href="https://www.compareprix.in" /><link rel="preconnect" href="https://www.compareprix.in" /><link rel="dns-prefetch" href="https://www.google.com" /><link rel="preconnect" href="https://www.google.com" /><link rel="dns-prefetch" href="https://www.googletagmanager.com/" /><link rel="preconnect" href="https://www.googletagmanager.com/" /><link rel="dns-prefetch" href="https://googleads.g.doubleclick.net" /><link rel="preconnect" href="https://googleads.g.doubleclick.net" /><link rel="dns-prefetch" href="https://www.dmca.com" /><link rel="preconnect" href="https://www.dmca.com" /><link rel="dns-prefetch" href="https://images.dmca.com" /><link rel="preconnect" href="https://images.dmca.com" /><link rel="dns-prefetch" href="https://d5nxst8fruw4z.cloudfront.net/" /><link rel="preconnect" href="https://d5nxst8fruw4z.cloudfront.net/" /><link rel="dns-prefetch" href="https://ajax.googleapis.com/" /><link rel="preconnect" href="https://ajax.googleapis.com/" />

    <script defer type="text/javascript" src="https://www.compareprix.in/scripts/externaljs.php?url=gtm.js"></script>
    <!-- Google Tag Manager -->
<script>
    (function (w, d, s, l, i) { w[l] = w[l] || []; w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' }); var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = !0; j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f) })(window, document, 'script', 'dataLayer', 'GTM-P7MLBBS')</script>
<!-- End Google Tag Manager -->

<link rel="manifest" href="https://www.compareraja.in/notification_manifest.json" />
    <meta name="google-site-verification" content="n6r_PCbPMVN9X4icKm7m3y9SIw84L2tk9hjQ0mo48LQ" />
    <link rel="canonical" media="screen" href="https://www.compareraja.in">
    <link media="only screen and (max-width: 640px)" rel="alternate" href="https://m.compareraja.in" />
</head>
<body> 
    <form name="aspnetForm" method="post" action="" id="aspnetForm">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTQ5NTU1NTQyMGRk9kIex5UUZ27uzkXrlxFCP4OkIke6Lass1eRqHghM0dc=" />
</div>

<div>

    <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdABFRwwNVuqd38xkmqJyi2QpC6psceWc1PGtVTL1Kq7QJEc7r+Q2wzLG+BtL5lJSqr9ECmX+fXUUUVr647KnuLgZLsV828vaneTtS6o9A1RKqrJGjlMdCpU2lfYIS7whVajlMwefZvjAfWYXG1Qb+tu0DVMH1CknH+SBEXPirurnlC84tXOzJSN70AjIstfunTxMkt4zFG4AEnqj9yejjaN/6JDjO4LwxH7CO3yKdpkzuZyJWgAz1t+agjxA16Icj6ZuuVrJNwSEef3rQCKWDMmRJTUdDTUzwdV9z8v/HMNU3KDvYtlANTbqN6QOK3/N6vtHMOglEiOvUf0mI8IFJMedxsezVbp7pCoWJ52NCvwpaNwII/l6PMseUEteDsjpCmlOjWYISIPrvcKOhRyiwIKkl" />
</div>
    
    
    <div>
        

<div class="searchoverlay" style="display: none;">
</div>
<div id="notifyoverlay" class="notifyoverlay">
</div>
<div class="header">
    <div class="container">
        <div class="logo">
            <!--logo.png-->
            <a href="https://www.compareraja.in/">
                <div class="comparelogo logo"> </div></a>
        </div>
        
<div id="searchbg" class="searchbox">
    <div id="searchtxtbx" class="search_area">
    <i class="icon-search"></i>
                <input name="ctl00$tophead$commonserach1$txtSearch" type="text" id="ctl00_tophead_commonserach1_txtSearch" class="search-input ui-autocomplete-input ui-autocomplete-loading" PlaceHolder="What are you looking for today? e.g. iPhone 6 plus" Value="What are you looking for today? e.g. iPhone 6 plus" onclick="javascript:make_blank(this);" onfocus="javascript:fnfocussearchbox(this);" onblur="javascript:onblursearchbox(this);" />                        
            <input type="submit" name="ctl00$tophead$commonserach1$btnSearch" value="" onclick="Javascript:return checkcurrentdata();" id="ctl00_tophead_commonserach1_btnSearch" class="search-btn" />
          
            <div id="divscrollsearch" class="compar-search" style="display: none;">
            </div>
            <input type="hidden" name="ctl00$tophead$commonserach1$hdnsetviewall" id="ctl00_tophead_commonserach1_hdnsetviewall" />
        
    </div>
</div>
<script type="text/jscript">
       document.getElementById("ctl00_tophead_commonserach1_txtSearch").value = '';
</script>  


        <div class="user" >
            <p class="ucircle" id="divuser">
                &nbsp;</p>
            
            
            <a id="signin-link" href="https://www.compareraja.in/signup-contest.htm" title="Login/Signup">Login/Signup</a>
            
        </div>
        <div class="header-banner">

                   
    

    
    <a href="https://www.compareraja.in/signup-contest.htm" title=" Signup and Win an Iphone 6" target="_blank" rel="nofollow">
        <img src="https://www.compareprix.in/images/encourage-sign-up-banner.gif" alt=" Signup and Win an Iphone 6" width="210px" height="76px"/>
    </a>

    
        </div>
        <div class="clear">
        </div>
    </div>
</div>
<!--Header Close-->
<!--Menu Start-->
<div class="nav-container">
<div class="container">
    <ul class="nav">
        <!-- Full Drop Down Contents  Ends  Here-->
        <!-- Regular Menu Button -->
        <li class="dropdown" id="liMobiles"><a style="cursor: pointer;" class="" href="https://www.compareraja.in/mobiles.html">
            Mobiles</a>
        </li>      
        <li class="dividline"></li>      
        <li class="dropdown" id="liTVs"><a style="cursor: pointer;" class="" href="https://www.compareraja.in/televisions.html">
            TVs</a>
        </li>
        <li class="dividline"></li>
        <li class="dropdown" id="liACs"><a style="cursor: pointer;" class="" href="https://www.compareraja.in/air-conditioners.html">
            ACs</a>
        </li>
        <li class="dividline"></li>
        <li class="dropdown" id="liLaptops"><a style="cursor: pointer;" class="" href="https://www.compareraja.in/laptops.html">
            Laptops</a>
        </li>
        <li class="dividline"></li>
        <li class="dropdown" id="liCameras"><a style="cursor: pointer;" class="" href="https://www.compareraja.in/washing-machines.html">
            Washing Machines</a>
        </li>
        <li class="dividline"></li>
        <li class="dropdown" id="li1"><a href="https://www.compareraja.in/refrigerators.html">
            Refrigerators</a>
        </li>
        <li class="dividline"></li>
        <li> <a href="https://www.compareraja.in/cameras.html" class="usedcarbtn">Cameras</a> </li>
        
        <li class="dividline"></li>
        <li class="dropdown" id="likids" style="position: static;"><a href="https://www.compareraja.in/all-categories.html">
            Electronics & more</a>
        </li>      
                
           
        
        
        
        <li class="dividline"></li>
             
    </ul>
    <p class="best-offer">
        <i class="pk"></i><i class="bl"></i><i class="gn"></i><i class="yl"></i><i class="og">
        </i><a href="https://www.compareraja.in/offerzone"
            title="Best Offers">Best Offers</a> <i class="pk"></i><i class="bl"></i><i class="gn">
            </i><i class="yl"></i><i class="og"></i>
    </p>
</div>
</div>
<div class="clear">
</div>
 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 <script type="text/javascript" language="javascript">
     $(document).ready(function () { $('#lifinance').hover(function () { $('#divhealth').load("https://www.compareraja.in/masterPages/controls/menudata.aspx?menucategory=Finance") }) })
</script>

<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('#signin-link_1').click(function () {
            if (jQuery('#signin-dropdown').is(":visible")) {
                jQuery('#signin-dropdown').hide()
                jQuery('#session').removeClass('active')
            } else {
                jQuery('#signin-dropdown').show()
                jQuery('#session').addClass('active')
            }
            return !1
        }); jQuery('#signin-dropdown').click(function (e) { e.stopPropagation() }); jQuery(document).click(function () { jQuery('#signin-dropdown').hide(); jQuery('#session').removeClass('active') })
    })
  </script>

  <script type="text/javascript">
      jQuery(document).ready(function () {
          jQuery('.active-links').click(function () {
              if (jQuery('#signin-dropdown').is(":visible")) { jQuery('#signin-dropdown').hide() } else { jQuery('#signin-dropdown').show() }
              return !1
          }); jQuery('#signin-dropdown').click(function (e) { e.stopPropagation() }); jQuery(document).click(function () { jQuery('#signin-dropdown').hide() })
      })
</script>
           
        <div class="container">
            
    <div class="clear ht-twenty">
    </div>
    <div class="container">
        <div class="home-banner ">
            <div class="hm-left fadeInUp">
                <div class="home-slider">
                    <article class="tab-slider">
            <div class="tabs-slider tabs_hover">
                <div id="tab-1">
                    
              
              <a rel="NOFOLLOW" href="https://www.amazon.in/gp/goldbox/ref=as_li_ss_tl?ie=UTF8&linkCode=ll2&tag=comparepromo-21&linkId=77b19ee3df28a7e5ae553059fe263220" title="" class="hdimg" target="_blank">
                    <img src="https://www.compareprix.in/images/homeslider/amazon-todays-deal-banner-expand-4.jpg?v=1" alt="" width='691' height='269'> 
                </a>
            </div>
              <div id="tab-2">
                
                <a href="https://www.flipkart.com/offers/deals-of-the-day?affid=compareraj&affExtParam1=cmraja&affExtParam2=flashbanner" rel="NOFOLLOW" target="_blank" title="" class="hdimg">
                    <img src="https://www.compareprix.in/images/homeslider/flipkart-offer-zone-banners.jpg?V=1" alt="" width='691' height='269'>
                </a>   
                  
            </div>
            
            <div id="tab-3">
                <a href="http://skyscanner.compareraja.in/" rel="NOFOLLOW" target="_blank" title="" class="hdimg">
                    <img src="https://www.compareprix.in/images/homeslider/skyscanner_flash_banner_desktop.jpg?V=1" alt="" width='691' height='269'>
                </a>
            </div>
            <div id="tab-4">             
                <a href="https://www.compareraja.in/add-on" title="" class="hdimg">
                    <img src="https://www.compareprix.in/images/homeslider/add-on-banner-1.jpg?V=1" alt="" width='691' height='269'>
                </a>
                
            </div>
              <ul class="horizontal">
              
                <li>
                
                
                
                   <a rel="NOFOLLOW" href="https://www.amazon.in/gp/goldbox/ref=as_li_ss_tl?ie=UTF8&linkCode=ll2&tag=comparepromo-21&linkId=77b19ee3df28a7e5ae553059fe263220" target="_blank" name="#tab-1">
                        <span class="arrow"></span>Today's Deals<i class="small-text">By Amazon</i>
                    </a>                 
                </li>
                <li>
                
                <a href="https://www.flipkart.com/offers/deals-of-the-day?affid=compareraj&affExtParam1=cmraja&affExtParam2=flashbanner" rel="NOFOLLOW" target="_blank" name="#tab-2">
                        <span class="arrow"></span>Great Offers<i class="small-text">By Flipkart</i>
                    </a>
                </li>

                
                <li>
                <a href="http://skyscanner.compareraja.in/" rel="NOFOLLOW" target="_blank" name="#tab-3">
                        <span class="arrow"></span>Flight Comparison <i class="small-text">by Skyscanner</i>
                    </a>
                </li>
                <li>
                    <a href="https://www.compareraja.in/add-on" name="#tab-4">
                        <span class="arrow"></span>Browser Addon <i class="small-text">Get Now</i>
                    </a>
                    
                    
                </li>
              </ul>
            </div>
          </article>
                </div>
            </div>
            <script async defer="defer" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
            

<div class="hm-right fadeInUp">
                <div class="compare-product">
                    <h2 class="slideInUp">
                        COMPARE PRODUCTS</h2>
                    <div class="comparefield">
                        <form class="custom" onsubmit="return(false)">
                            <p class="b-product">
                        <select name="ctl00$ContentPlaceHolder1$compareproduct1$contactDropdown" id="ctl00_ContentPlaceHolder1_compareproduct1_contactDropdown">
    <option value="mobiles">Mobiles</option>
    <option value="tablets">Tablets</option>
    <option value="cameras">Cameras</option>
    <option value="refrigerators">Refrigerators</option>
    <option value="washingmachines">Washing Machines</option>
    <option value="microwave-ovens">Microwave Ovens</option>
    <option value="hard-disks">Hard Disks</option>
    <option value="televisions">Televisions</option>
    <option value="printers">Printers</option>
    <option value="airconditioners">Airconditioners</option>

</select>
                            </p>
                        </form>
                        <p class="clear ht-fifteen">
                        </p>
                        <div class="b-product-cat">
                            <input name="ctl00$ContentPlaceHolder1$compareproduct1$txtHProduct1" type="text" id="ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct1" class="hm-rightsearchtxt" autocomplete="off" value="Type Product (1) Name" onblur="if(this.value==&#39;&#39;) this.value=&#39;Type Product (1) Name&#39;;" onfocus="if(this.value==&#39;Type Product (1) Name&#39;)this.value=&#39;&#39;;" />
                             <div id="dvsrchrslt1" class="homeserchrt">
               </div>    
                        </div>
                        <p class="b-vs">
                            V/S</p>
                        <div class="b-product-cat">
                            <input name="ctl00$ContentPlaceHolder1$compareproduct1$txtHProduct2" type="text" id="ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct2" class="hm-rightsearchtxt" autocomplete="off" value="Type Product (2) Name" onblur="if(this.value==&#39;&#39;) this.value=&#39;Type Product (2) Name&#39;;" onfocus="if(this.value==&#39;Type Product (2) Name&#39;)this.value=&#39;&#39;;" />
                              <div id="dvsrchrslt" class="homeserchrt">
               </div> </div>
                        <p class="clear ht-fifteen">
                        </p>
                    </div>
                    <p class="comfeature">
                        <input type="submit" name="ctl00$ContentPlaceHolder1$compareproduct1$btnSubmitCompare" value="COMPARE FEATURES" onclick="HRedirectToCompare(); return false;" id="ctl00_ContentPlaceHolder1_compareproduct1_btnSubmitCompare" />
                    </p>
                </div>
                                <input type="hidden" id="hdnHCatName"/>
         <input type="hidden" id="hdnHProId1" />
         <input type="hidden" id="hdnHProId2" />
         <input type="hidden" id="hdnHCompareIndicator" />
         <input type="hidden" id="hdnHcompare" />
            </div>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/jquery.homecomparepopup.js?v=1.2" ></script>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/jquery.homecomparepopup1.js?v=1.2" ></script>
    <script type="text/javascript" >
        var c = jQuery.noConflict(); var lnk4 = 'https://www.compareraja.in/' + 'autocompletedata.ashx'; c(document).ready(function () { c("#ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct1").autocompletecr2(lnk4); c("#ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct2").autocompletecr5(lnk4) }) 
</script>
<script type="text/javascript" >
    function HRedirectToCompare() {
        debugger; var em1 = document.getElementById('ctl00_ContentPlaceHolder1_compareproduct1_contactDropdown'); var strCategory1 = em1.options[em1.selectedIndex].value; var desired1 = strCategory1.split('~'); var cat = desired1[0]; var proid1 = document.getElementById('hdnHProId1').value; var proid2 = document.getElementById('hdnHProId2').value; var compareIndi = document.getElementById('hdnHCompareIndicator').value; var product1text = document.getElementById('ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct1').value; var product2text = document.getElementById('ctl00_ContentPlaceHolder1_compareproduct1_txtHProduct2').value; if (cat == "airconditioners") { cat = "air-conditioners" }
        if (cat == "washingmachines") { cat = "washing-machines" }
        if (proid1 != "" && proid2 != "") {
            var x = Math.floor(proid1); var y = Math.floor(proid2); if (x < y) { window.location.href = "https://www.compareraja.in/compare-" + cat + "?pid1=" + proid1 + "&pid2=" + proid2 }
            else { window.location.href = "https://www.compareraja.in/compare-" + cat + "?pid1=" + proid2 + "&pid2=" + proid1 } 
        }
        else if (proid1 == "" && proid2 == "") { alert('Product Is not Available To Compare, Please Search for Some Other Product.') }
        else if (proid1 != "" && proid2 == "") { alert('Please Search Second Product to Compare') }
        else if (proid1 == "" && proid2 != "") { alert('Please Search first Product to Compare') }
        else { alert('Product Is not Available To Compare, Please Search for Some Other Product.') } 
    }
</script>
        </div>
        <div class="clear ht-ten">
        </div>
        <p class="com-pr-fr fadeInUp">
            Compare Prices From</p>
        <p class="clear ht-five">
        </p>
        <div class="cpm-pr-box-logo fadeInUp">
            <img src="https://www.compareprix.in/images/home-logo-strip-v3.jpg" width="1212"
                height="69" alt="">
            <div class="clear ht-ten">
            </div>
        </div>
        

<div class="trndnews">
      <p class="left cat-title">Trending Stories &amp; News</p>
      <div class="tsnLst">
        <ul>
            
                    <li> 
                    <a href="https://www.compareraja.in/blog/all-you-need-to-know-about-amazon-fire-stick/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/all-you-need-to-know-about-amazon-fire-stick-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">All You Need to Know about Amazon Fire Stick</div>
                        <div class="newsDate">04 Nov 2017</div>
                    </a>
                    </li>
                
                    <li> 
                    <a href="https://www.compareraja.in/blog/huawei-launches-honor-holly-4-plus-for-rs-13999/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/huawei-launches-honor-holly-4-plus-for-rs-13999-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">Huawei Launches Honor Holly 4 Plus For Rs 13,999</div>
                        <div class="newsDate">04 Nov 2017</div>
                    </a>
                    </li>
                
                    <li> 
                    <a href="https://www.compareraja.in/blog/xiaomi-launches-watered-down-redmi-y-lite-for-rs-6999/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/xiaomi-launches-watered-down-redmi-y-lite-for-rs-6999-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">Xiaomi Launches Watered-Down Redmi Y1 Lite For Rs 6,999</div>
                        <div class="newsDate">03 Nov 2017</div>
                    </a>
                    </li>
                
                    <li> 
                    <a href="https://www.compareraja.in/blog/htc-unveils-u11-life-under-google-android-one-programme/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/htc-unveils-u11-life-under-google-android-one-programme-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">HTC Unveils U11 Life Under Google Android One Programme</div>
                        <div class="newsDate">03 Nov 2017</div>
                    </a>
                    </li>
                
                    <li> 
                    <a href="https://www.compareraja.in/blog/xiaomis-budget-redmi-y1-offers-a-16-mp-selfie-camera/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/xiaomis-budget-redmi-y1-offers-a-16-mp-selfie-camera-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">Xiaomi Launches A Selfie-Centric Redmi Y1 On Budget</div>
                        <div class="newsDate">03 Nov 2017</div>
                    </a>
                    </li>
                
                    <li> 
                    <a href="https://www.compareraja.in/blog/orient-launches-stylish-yet-robust-enamour-water-heater/" target="_blank"> 
                        <img src="https://www.compareprix.in/images/trendingstoriesandnews/orient-launches-stylish-yet-robust-enamour-water-heater-ds.jpg" width="380" height="260" alt=""/>
                        <div class="newsTitle">Orient Launches Stylish Yet Robust Enamour Water Heater</div>
                        <div class="newsDate">30 Oct 2017</div>
                    </a>
                    </li>
                

        </ul>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
        <div class="clear ht-ten">
        </div>
        <h1 class="tp-hd heading center fadeInUp bold">
            PRICE COMPARISON</h1>
        <div class="clear ht-ten">
        </div>
        <div class="home-pop-cate">
            <div class="topsec fadeInUp">
                <p class="left cat-title">
                    POPULAR CATEGORIES</p>
                <p class="right">
                    <a class="all-category" title="View All Categories" href="https://www.compareraja.in/all-categories.html">
                        View All Categories</a></p>
                <div class="clear">
                </div>
            </div>
            <div class="clear ht-twenty">
            </div>
            <ul>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/mobiles.html" title="Compare Mobile Prices" class="link">
                            <h3>
                                Mobile Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/mobiles/apple-mobile-prices.html">Apple iPhones</a></li>
                            <li><a href="https://www.compareraja.in/mobiles/samsung-mobile-prices.html">Samsung
                                Mobiles</a></li>
                            <li><a href="https://www.compareraja.in/mobiles/micromax-mobile-prices.html">Micromax
                                Mobiles</a></li>
                            <li><a href="https://www.compareraja.in/mobiles/lenovo-mobile-prices.html">Lenovo Mobiles</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/mobiles.html" title="Compare Mobile Prices"><span
                                    class="mobile-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/tablets.html" title="Compare Tablet Prices" class="link">
                            <h3>
                                Tablet Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/tablets/apple-tablet-prices.html">Apple iPads</a></li>
                            <li><a href="https://www.compareraja.in/tablets/samsung-tablet-prices.html">Samsung
                                Tablets</a></li>
                            <li><a href="https://www.compareraja.in/tablets/iball-tablet-prices.html">iBall Tablets</a></li>
                            <li><a href="https://www.compareraja.in/tablets/micromax-tablet-prices.html">Micromax
                                Tablets</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/tablets.html" title="Compare Tablet Prices"><span
                                    class="tablet-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/laptops.html" title="Compare Laptop Prices" class="link">
                            <h3>
                                Laptop Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/laptops/apple-laptop-prices.html">Macbooks</a></li>
                            <li><a href="https://www.compareraja.in/laptops/hp-laptop-prices.html">HP Laptops</a></li>
                            <li><a href="https://www.compareraja.in/laptops/dell-laptop-prices.html">Dell Laptops</a></li>
                            <li><a href="https://www.compareraja.in/laptops/lenovo-laptop-prices.html">Lenovo Laptops</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/laptops.html" title="Compare Laptop Prices"><span
                                    class="laptop-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/printers.html" title="Compare Printers Prices"
                            class="link">
                            <h3>
                                Printer Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/printers/epson-printer-prices.html">Epson Printers</a></li>
                            <li><a href="https://www.compareraja.in/printers/canon-printer-prices.html">Canon Printers</a></li>
                            <li><a href="https://www.compareraja.in/printers/hp-printer-prices.html">HP Printers</a></li>
                            <li><a href="https://www.compareraja.in/printers/samsung-printer-prices.html">Samsung
                                Printers</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/printers.html" title="Compare Printers Prices"><span
                                    class="printer-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/cameras.html" title="Compare Cameras Prices"
                            class="link">
                            <h3>
                                Camera Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/cameras/nikon-camera-prices.html">Nikon Cameras</a></li>
                            <li><a href="https://www.compareraja.in/cameras/canon-camera-prices.html">Canon Cameras</a></li>
                            <li><a href="https://www.compareraja.in/cameras/sony-camera-prices.html">Sony Cameras</a></li>
                            <li><a href="https://www.compareraja.in/cameras/fujifilm-camera-prices.html">Fujifilm
                                Cameras</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/cameras.html" title="Compare Cameras Prices"><span
                                    class="camera-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/televisions.html" title="Compare Television Prices"
                            class="link">
                            <h3>
                                Television Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/televisions/sony-television-prices.html">Sony
                                Televisions</a></li>
                            <li><a href="https://www.compareraja.in/televisions/samsung-television-prices.html">
                                Samsung Televisions</a></li>
                            <li><a href="https://www.compareraja.in/televisions/micromax-television-prices.html">
                                Micromax Televisions</a></li>
                            <li><a href="https://www.compareraja.in/televisions/vu-television-prices.html">Vu Televisions</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/televisions.html" title="Compare Television Prices">
                                    <span class="tv-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/air-conditioners.html" title="Compare Air Conditioner Prices"
                            class="link">
                            <h3>
                                Air Conditioner Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/airconditioners/voltas-airconditioner-prices.html">
                                Voltas Air Conditioners</a></li>
                            <li><a href="https://www.compareraja.in/airconditioners/bluestar-airconditioner-prices.html">
                                Blue Star Air Conditioners</a></li>
                            <li><a href="https://www.compareraja.in/airconditioners/daikin-airconditioner-prices.html">
                                Daikin Air Conditioners</a></li>
                            <li><a href="https://www.compareraja.in/airconditioners/lg-airconditioner-prices.html">
                                LG Air Conditioners</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/air-conditioners.html" title="Compare Air Conditioner Prices">
                                    <span class="ac-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/air-coolers.html" title="Compare Air Coolers Prices"
                            class="link">
                            <h3>
                                Air Cooler Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/aircoolers/symphony-aircooler-prices.html">Symphony
                                Air Coolers</a></li>
                            <li><a href="https://www.compareraja.in/aircoolers/bajaj-aircooler-prices.html">Bajaj
                                Air Coolers</a></li>
                            <li><a href="https://www.compareraja.in/aircoolers/voltas-aircooler-prices.html">Voltas
                                Air Coolers</a></li>
                            <li><a href="https://www.compareraja.in/aircoolers/kenstar-aircooler-prices.html">Kenstar
                                Air Coolers</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/air-coolers.html" title="Compare Air Coolers Prices">
                                    <span class="aircooler-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/refrigerators.html" title="Compare Refrigerator Prices"
                            class="link">
                            <h3>
                                Refrigerator Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/refrigerators/samsung-refrigerator-prices.html">
                                Samsung Refrigerators</a></li>
                            <li><a href="https://www.compareraja.in/refrigerators/whirlpool-refrigerator-prices.html">
                                Whirlpool Refrigerators</a></li>
                            <li><a href="https://www.compareraja.in/refrigerators/lg-refrigerator-prices.html">LG
                                Refrigerators</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/refrigerators.html" title="Compare Refrigerator Prices">
                                    <span class="refrigerator-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/washing-machines.html" title="Compare Washing Machine Prices"
                            class="link">
                            <h3>
                                Washing Machine Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/washingmachines/lg-washingmachine-prices.html">
                                LG Washing Machines</a></li>
                            <li><a href="https://www.compareraja.in/washingmachines/samsung-washingmachine-prices.html">
                                Samsung Washing Machines</a></li>
                            <li><a href="https://www.compareraja.in/washingmachines/ifb-washingmachine-prices.html">
                                IFB Washing Machines</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/washing-machines.html" title="Compare Washing Machine Prices">
                                    <span class="washing-machine-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/microwave-ovens.html" title="Compare Microwave Oven Prices"
                            class="link">
                            <h3>
                                Microwave Oven Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/microwaveovens/samsung-microwaveoven-prices.html">
                                Samsung Microwave Ovens</a></li>
                            <li><a href="https://www.compareraja.in/microwaveovens/lg-microwaveoven-prices.html">
                                LG Microwave Ovens</a></li>
                            <li><a href="https://www.compareraja.in/microwaveovens/ifb-microwaveoven-prices.html">
                                IFB Microwave Ovens</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/microwave-ovens.html" title="Compare Microwave Oven Prices">
                                    <span class="microwave-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/choppers-and-blenders.html" title="Compare Chopper and Blenders Prices"
                            class="link">
                            <h3>
                                Chopper and Blender Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/choppersandblenders/philips-chopperandblender-prices.html">
                                Philips Choppers & Blenders Price List</a></li>
                            <li><a href="https://www.compareraja.in/choppersandblenders/orpat-chopperandblender-prices.html">
                                Orpat Choppers & Blenders</a></li>
                            <li><a href="https://www.compareraja.in/choppersandblenders/maharaja-whiteline-chopperandblender-prices.html">
                                Maharaja Whiteline Chopper & Blender</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/choppers-and-blenders.html" title="Compare Chopper and Blenders Prices"
                                    class="link"><span class="choppers-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/juicer-mixer-grinders.html" title="Compare Juicer Mixer Grinders Prices"
                            class="link">
                            <h3>
                                Juicer Mixer Grinder Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/juicermixergrinders/bajaj-juicermixergrinder-prices.html">
                                Bajaj Juicer Mixer Grinders</a></li>
                            <li><a href="https://www.compareraja.in/juicermixergrinders/philips-juicermixergrinder-prices.html">
                                Philips Juicer Mixer Grinders</a></li>
                            <li><a href="https://www.compareraja.in/juicermixergrinders/prestige-juicermixergrinder-prices.html">
                                Prestige Juicer Mixer Grinders</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/juicer-mixer-grinders.html" title="Compare Juicer Mixer Grinders Prices">
                                    <span class="juicer-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/electric-cookers.html" title="Compare Electric Cookers Prices"
                            class="link">
                            <h3>
                                Electric Cooker Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/electriccookers/prestige-electriccooker-prices.html">
                                Prestige Electric Cookers</a></li>
                            <li><a href="https://www.compareraja.in/electriccookers/panasonic-electriccooker-prices.html">
                                Panasonic Electric Cookers</a></li>
                            <li><a href="https://www.compareraja.in/electriccookers/bajaj-electriccooker-prices.html">
                                Bajaj Electric Cookers</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/electric-cookers.html" title="Compare Electric Cookers Prices">
                                    <span class="electric-cooker-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/induction-cooktops.html" title="Compare Induction Cooktops Prices"
                            class="link">
                            <h3>
                                Induction Cooktop Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/inductioncooktops/prestige-inductioncooktop-prices.html">
                                Prestige Induction Cooktops</a></li>
                            <li><a href="https://www.compareraja.in/inductioncooktops/philips-inductioncooktop-prices.html">
                                Philips Induction Cooktops</a></li>
                            <li><a href="https://www.compareraja.in/inductioncooktops/bajaj-inductioncooktop-prices.html">
                                Bajaj Induction Cooktops</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/induction-cooktops.html" title="Compare Induction Cooktops Prices">
                                    <span class="induction-cooktop-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/water-purifiers.html" title="Compare Water Purifier Prices"
                            class="link">
                            <h3>
                                Water Purifier Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/waterpurifiers/kent-waterpurifier-prices.html">
                                Kent Water Purifiers</a></li>
                            <li><a href="https://www.compareraja.in/waterpurifiers/eureka-forbes-waterpurifier-prices.html">
                                Eureka Forbes Water Purifiers</a></li>
                            <li><a href="https://www.compareraja.in/waterpurifiers/hul-waterpurifier-prices.html">
                                HUL Water Purifiers</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/water-purifiers.html" title="Compare Water Purifier Prices"
                                    class="link"><span class="water-purifier-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/water-heaters.html" title="Compare Water Heater Prices"
                            class="link">
                            <h3>
                                Water Heater Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/waterheaters/bajaj-waterheater-prices.html"
                                title="">Bajaj Water Heater Price</a> </li>
                            <li><a href="https://www.compareraja.in/waterheaters/v-guard-waterheater-prices.html"
                                title="">V Guard Water Heater Price</a> </li>
                            <li><a href="https://www.compareraja.in/waterheaters/racold-waterheater-prices.html"
                                title="">Racold Water Heater Price</a> </li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/water-heaters.html" title="Compare Water Heater Prices"
                                    class="link"><span class="Water-Heaters-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/room-heaters.html" title="Compare Room Heater Prices"
                            class="link">
                            <h3>
                                Room Heater Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/roomheaters/bajaj-roomheater-prices.html">Bajaj
                                Room Heaters</a></li>
                            <li><a href="https://www.compareraja.in/roomheaters/usha-roomheater-prices.html">Usha
                                Room Heaters</a></li>
                            <li><a href="https://www.compareraja.in/roomheaters/orpat-roomheater-prices.html">Orpat
                                Room Heaters</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/room-heaters.html" title="Compare Room Heater Prices"
                                    class="link"><span class="room-heaters-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/hair-straighteners.html" title="Compare Hair Straightener Prices"
                            class="link">
                            <h3>
                                Hair Straightener Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/hairstraighteners/philips-hairstraightener-prices.html">
                                Philips Hair Straighteners</a></li>
                            <li><a href="https://www.compareraja.in/hairstraighteners/nova-hairstraightener-prices.html">
                                Nova Hair Straighteners</a></li>
                            <li><a href="https://www.compareraja.in/hairstraighteners/panasonic-hairstraightener-prices.html">
                                Panasonic Hair Straighteners</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/hair-straighteners.html" title="Compare Hair Straightener Prices"
                                    class="link"><span class="hair-straightener-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/hair-dryers.html" title="Compare Hair Dryer Prices"
                            class="link">
                            <h3>
                                Hair Dryer Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/hairdryers/philips-hairdryer-prices.html">Philips
                                Hair Dryers</a></li>
                            <li><a href="https://www.compareraja.in/hairdryers/nova-hairdryer-prices.html">Nova
                                Hair Dryers</a></li>
                            <li><a href="https://www.compareraja.in/hairdryers/vega-hairdryer-prices.html">Vega
                                Hair Dryers</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/hair-dryers.html" title="Compare Hair Dryer Prices"
                                    class="link"><span class="hair-dryer-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/trimmers.html" title="Compare Trimmers &amp; Shavers Prices"
                            class="link">
                            <h3>
                                Trimmer &amp; Shaver Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/trimmers/philips-trimmer-prices.html">Philips
                                Trimmers</a></li>
                            <li><a href="https://www.compareraja.in/trimmers/syska-trimmer-prices.html">Syska Trimmers</a></li>
                            <li><a href="https://www.compareraja.in/trimmers/nova-trimmer-prices.html">Nova Trimmer</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/trimmers.html" title="Compare Trimmers &amp; Shavers Prices"
                                    class="link"><span class="trimmer-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/router-and-modems.html" title="Compare Router and Modems Prices"
                            class="link">
                            <h3>
                                Router &amp; Modem Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/routerandmodems/d-link-routerandmodem-prices.html">
                                D-Link Router And Modems</a></li>
                            <li><a href="https://www.compareraja.in/routerandmodems/tp-link-routerandmodem-prices.html">
                                TP-Link Router And Modems</a></li>
                            <li><a href="https://www.compareraja.in/routerandmodems/linksys-routerandmodem-prices.html">
                                Linksys Router And Modems</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/router-and-modems.html" title="Compare Router and Modems Prices"
                                    class="link"><span class="router-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/power-banks.html" title="Compare Power Banks Prices"
                            class="link">
                            <h3>
                                Power Bank Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/powerbanks/intex-powerbank-prices.html">Intex
                                Power Banks</a></li>
                            <li><a href="https://www.compareraja.in/powerbanks/lenovo-powerbank-prices.html">Lenovo
                                Power Banks</a></li>
                            <li><a href="https://www.compareraja.in/powerbanks/pny-powerbank-prices.html">PNY Power
                                Banks</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/power-banks.html" title="Compare Power Banks Prices"
                                    class="link"><span class="power-bank-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                
                <li>
                    <div class="leftcon">
                        <a href="https://www.compareraja.in/hard-disks.html" title="Compare Hard Disks Prices"
                            class="link">
                            <h3>
                                Hard Disk Price List</h3>
                        </a>
                        <ul class="subcat">
                            <li><a href="https://www.compareraja.in/harddisks/seagate-harddisk-prices.html">Seagate
                                Hard Disks</a></li>
                            <li><a href="https://www.compareraja.in/harddisks/western-digital-harddisk-prices.html">
                                Western Digital Hard Disks</a></li>
                            <li><a href="https://www.compareraja.in/harddisks/sony-harddisk-prices.html">Sony Hard
                                Disks</a></li>
                        </ul>
                    </div>
                    <div class="rightcon1">
                        <div class="rightcon">
                            <div class="productico">
                                <a href="https://www.compareraja.in/hard-disks.html" title="Compare Hard Disks Prices"
                                    class="link"><span class="hard-disk-ico"></span></a>
                            </div>
                        </div>
                    </div>
                </li>
                
            </ul>
        </div>
        <div class="clear ht-ten">
        </div>
        <div class="home-best-sel">
            <p class="cat-title">
                Best Selling/Upcoming Mobiles as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/apple-iphone-8-64-gb-price.html" title="Apple iPhone 8 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/iPhone8.jpeg"
                            alt="Apple iPhone 8" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 8 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-8-plus-64-gb-price.html" title="Apple iPhone 8 Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/apple-iphone-8-plus.png"
                            alt="Apple iPhone 8 Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 8 Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-x-price.html" title="Apple  iPhone X Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/apple-iphone-x-1.jpg"
                            alt="Apple  iPhone X" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone X Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-6-16-gb-price.html" title="Apple iPhone 6 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/apple-iphone-6.jpg"
                            alt="Apple iPhone 6" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 6 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-6s-16-gb-price.html" title="Apple iPhone 6s Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/apple-iphone-6s-16-gbS-hp.jpg?v=1"
                            alt="Apple iPhone 6s" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 6s Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-6s-plus-16-gb-price.html" title="Apple iPhone 6s Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/Apple-iPhone-6s-Plus.jpeg"
                            alt="Apple iPhone 6s Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 6s Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-7-32-gb-price.html" title="Apple iPhone 7 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/Apple-iPhone-7.jpg"
                            alt="Apple iPhone 7" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 7 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/apple-iphone-7-plus-32-gb-price.html" title="Apple iPhone 7 Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/Apple-iPhone-7-plus.jpg"
                            alt="Apple iPhone 7 Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Apple iPhone 7 Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/huawei-honor-8-pro-price.html" title="Huawei Honor 8 Pro Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/huawei-honor-8-pro-new-2017.jpg"
                            alt="Huawei Honor 8 Pro" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Huawei Honor 8 Pro Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/motorola-moto-e4-plus-price.html" title="Motorola Moto E4 Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/moto-e4-plus.png"
                            alt="Motorola Moto E4 Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Motorola Moto E4 Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/motorola-moto-g5s-price.html" title="Moto G5S Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/moto-g5s.png"
                            alt="Moto G5S" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Moto G5S Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/motorola-moto-g5s-plus-price.html" title="Motorola Moto G5S Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/moto-g5s-plus.png"
                            alt="Motorola Moto G5S Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Motorola Moto G5S Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/nokia-6-price.html" title="Nokia 6 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/Nokia-6-large.jpg"
                            alt="Nokia 6" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Nokia 6 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/oneplus-3t-price.html" title="OnePlus 3T Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/oneplus3t.jpg"
                            alt="OnePlus 3T" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        OnePlus 3T Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/oneplus-5-64-gb-with-6-gb-ram-price.html"
                    title="OnePlus 5 Price" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/oneplus-5-new-2017.jpg"
                            alt="OnePlus 5" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        OnePlus 5 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/oppo-f3-plus-price.html" title="Oppo F3 Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/v1/oppo-f3-plus.png"
                            alt="Oppo F3 Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Oppo F3 Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-galaxy-s8-price.html" title="Samsung Galaxy S8 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/v1/samsung-galaxy-s8.jpg?v=1"
                            alt="Samsung Galaxy S8" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Samsung Galaxy S8 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-galaxy-s8-plus-price.html" title="Samsung Galaxy S8 Plus Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/samsung-galaxy-s8-plus-new-2017.jpg"
                            alt="Samsung Galaxy S8 Plus" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Samsung Galaxy S8 Plus Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-galaxy-note-8-price.html" title="Samsung Galaxy Note 8 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/Samsung-Galaxy-Note-8-imagehp.jpg"
                            alt="Samsung Galaxy Note 8" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Samsung Galaxy Note 8 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-galaxy-j7-max-price.html" title="Samsung Galaxy J7 Max Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/samsung-j7-max.png"
                            alt="Samsung Galaxy J7 Max" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Samsung Galaxy J7 Max Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/vivo-v7-plus-price.html" title="Vivo V7+ Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/vivo-v7-plus.png"
                            alt="Vivo V7+" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Vivo V7+ Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/vivo-v5-price.html" title="Vivo V5 Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/vivo-v5-homepage.jpg"
                            alt="Vivo V5" width="70" height="145" /></p>
                    <p class="product-txt">
                        Vivo V5 Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/vivo-v5s-price.html" title="Vivo V5s Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/vivo-v5s-imagehp.jpg"
                            alt="Vivo V5s" width="70" height="145" /></p>
                    <p class="product-txt">
                        Vivo V5s Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/xiaomi-redmi-4a-16-gb-with-2-gb-ram-price.html"
                    title="Xiaomi Redmi 4A" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/mobile/v1/xiaomi-redmi-4a-16-gb-with-2-gb-ram.png"
                            alt="Xiaomi Redmi 4A" width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Xiaomi Redmi 4A</p>
                </a></li>
            </ul>
            <p class="cat-title">
                Best Selling TV as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/vu-32k160m-android-32-inch-hd-ready-smart-led-television-price.html"
                    title="VU 32K160M 32 Inch HD Ready Smart LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/vu-32k160m-android-32-inch-hp.jpeg?v=0.01"
                            alt="VU 32K160M 32 Inch HD Ready Smart LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        VU 32K160M 32 Inch HD Ready Smart LED Television</p>
                </a></li>
<li><a href="https://www.compareraja.in/samsung-32j4003-32-inch-hd-led-television-price.html"
                    title="Samsung 32J4003 32 Inch HD LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/samsung-32j4003-32-inch-hp.jpeg?v=0.01"
                            alt="Samsung Samsung 32J4003 32 Inch HD LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        Samsung 32J4003 32 Inch HD LED Television</p>
                </a></li>
<li><a href="https://www.compareraja.in/panasonic-th-43es630d-43-inch-full-hd-smart-led-television-price.html"
                    title="Panasonic TH-43ES630D 43 Inch Full HD Smart LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/panasonic-th-43es630d-43-inch-hp.jpg?v=0.01"
                            alt="Panasonic TH-43ES630D 43 Inch Full HD Smart LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        Panasonic TH-43ES630D 43 Inch Full HD Smart LED Television</p>
                </a></li>
<li><a href="https://www.compareraja.in/micromax-32-canvas-s2-32-inch-hd-ready-smart-led-television-price.html"
                    title="Micromax 32 Canvas S2 32 Inch HD Ready Smart LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/micromax-32-canvas-s2-32-inch-hp.jpeg?v=0.01"
                            alt="Micromax 32 Canvas S2 32 Inch HD Ready Smart LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        Micromax 32 Canvas S2 32 Inch HD Ready Smart LED Television</p>
                </a></li>
<li><a href="https://www.compareraja.in/sony-bravia-klv-32w672e-32-inch-full-hd-smart-led-television-price.html"
                    title="Sony Bravia KLV-32W672E 32 Inch Full HD Smart LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/sony-bravia-klv-32w672e-32-inch-hp.jpeg?v=0.01"
                            alt="Sony Bravia KLV-32W672E 32 Inch Full HD Smart LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        Sony Bravia KLV-32W672E 32 Inch Full HD Smart LED Television</p>
                </a></li>
<li><a href="https://www.compareraja.in/lg-32lj616d-32-inch-hd-smart-led-television-price.html"
                    title="LG 32LJ616D 32 Inch HD Smart LED Television" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/tv/lg-32lj616d-32-inch-hp.jpeg?v=0.01"
                            alt="LG 32LJ616D 32 Inch HD Smart LED Television" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        LG 32LJ616D 32 Inch HD Smart LED Television</p>
                </a></li>
            </ul>
            <p class="cat-title">
                Best Selling ACs as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/voltas-155-cy-1-2-ton-5-star-split-ac-price.html"
                    title="Voltas 155 CY 1.2 Ton 5 Star Split AC" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/Voltas-155-CY-1.2-Ton-5-Star-Split-AC-new-2017.png"
                            alt="Voltas 155 CY 1.2 Ton 5 Star Split AC" width="147" height="147" />
                    </p>
                    <p class="product-txt">
                        Voltas 155 CY 1.2 Ton 5 Star Split AC</p>
                </a></li>
                <li><a href="https://www.compareraja.in/voltas-122-dy-1-ton-2-star-split-ac-price.html"
                    title="Voltas 122 DY 1 Ton 2 Star Split AC" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/voltas-122-dy-1-ton-2-star-split-ac-new-2017.jpg"
                            alt="Voltas 122 DY 1 Ton 2 Star Split AC" width="147" height="147" />
                    </p>
                    <p class="product-txt">
                        Voltas 122 DY 1 Ton 2 Star Split AC</p>
                </a></li>
                <li><a href="https://www.compareraja.in/hyundai-hse53-gr1-qge-1-5-ton-3-star-split-ac-price.html"
                    title="Hyundai HSE53 GR1 QGE 1.5 Ton 3 Star Split AC" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/hyundai-hse53-gr1-qge-1-5-ton-3-star-split-ac-new-2017.jpg"
                            alt="Hyundai HSE53 GR1 QGE 1.5 Ton 3 Star Split AC" width="147" height="147" />
                    </p>
                    <p class="product-txt">
                        Hyundai HSE53 GR1 QGE 1.5 Ton 3 Star Split AC</p>
                </a></li>
                <li><a href="https://www.compareraja.in/lg-bsa18ibe-1-5-ton-inverter-split-ac-price.html"
                    title="LG BSA18IBE 1.5 Ton Inverter Split AC Price" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/LG_20BSA18IBE_201.5_20Ton_20Inverter_20Split_20AC-new-2017.jpg"
                            alt="LG BSA18IBE 1.5 Ton Inverter Split AC" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        LG BSA18IBE 1.5 Ton Inverter Split AC Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/hitachi-kaze-plus-raw318kud-1-5-ton-3-star-window-ac-price.html"
                    title="Hitachi Kaze Plus RAW318KUD 1.5 Ton 3 Star Window AC" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/Hitachi-Kaze-plus-RAW318KUD-new-2017.jpg"
                            alt="Hitachi Kaze Plus RAW318KUD 1.5 Ton 3 Star Window AC" width="147" height="147" />
                    </p>
                    <p class="product-txt">
                        Hitachi Kaze Plus RAW318KUD 1.5 Ton 3 Star Window AC</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-ar12mv3hewk-1-ton-3-star-inverter-split-ac-price.html"
                    title="Samsung AR12MV3HEWK 1 Ton 3 Star Inverter Split AC" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/ac/v1/samsung-ar12mv3hewk-1-ton-3-star-inverter-new-2017.jpg"
                            alt="Samsung AR12MV3HEWK 1 Ton 3 Star Inverter Split AC" width="147" height="147" />
                    </p>
                    <p class="product-txt">
                        Samsung AR12MV3HEWK 1 Ton 3 Star Inverter Split AC</p>
                </a></li>
            </ul>
            <p class="cat-title">
                Best Selling Refrigerator as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/lg-gl-i292rpzl-double-door-260-litres-frost-free-refrigerator-price.html"
                    title="LG GL I292RPZL Double Door 260 Litres Frost Free Refrigerator Price" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/I292RPZL-new-2017.jpeg"
                            alt="LG GL I292RPZL Double Door 260 Litres Frost Free Refrigerator" width="147"
                            height="147">
                    </p>
                    <p class="product-txt">
                        LG GL I292RPZL Double Door 260 Litres Frost Free Refrigerator Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/samsung-rr19k173zrz-hl-single-door-192-litres-direct-cool-refrigerator-price.html"
                    title="Samsung RR19K173ZRZ HL Single Door 192 Litres Direct Cool Refrigerator"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/Samsung-RR19K173ZRZ-hl-new-2017.jpg"
                            alt="Samsung RR19K173ZRZ HL Single Door 192 Litres Direct Cool Refrigerator"
                            width="70" height="145" />                           
                            
                    </p>
                    <p class="product-txt">
                        Samsung RR19K173ZRZ HL Single Door 192 Litres Direct Cool Refrigerator</p>
                </a></li>
                <li><a href="https://www.compareraja.in/godrej-rt-eon-231-c-2-4-double-door-231-litres-frost-free-refrigerator-price.html"
                    title="Godrej RT EON 231 C 2.4 Double Door 231 Litres Frost Free Refrigerator"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/Godrej-RT-EON-231-new-2017.jpg"
                            alt="Godrej RT EON 231 C 2.4 Double Door 231 Litres Frost Free Refrigerator"
                            width="70" height="145" />
                    </p>
                    <p class="product-txt">
                        Godrej RT EON 231 C 2.4 Double Door 231 Litres Frost Free Refrigerator</p>
                </a></li>
                <li><a href="https://www.compareraja.in/haier-hrb-3404bs-r-double-door-320-litres-frost-free-refrigerator-price.html"
                    title="Haier HRB 3404BS R Double Door 320 Litres Frost Free Refrigerator" class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/Haier-HRB-3404BS-R-new-2017.jpg"
                            alt="Haier HRB 3404BS R Double Door 320 Litres Frost Free Refrigerator" width="70"
                            height="145" />
                    </p>
                    <p class="product-txt">
                        Haier HRB 3404BS R Double Door 320 Litres Frost Free Refrigerator</p>
                </a></li>
                <li><a href="https://www.compareraja.in/whirlpool-fp-263d-royal-triple-door-240-litres-frost-free-refrigerator-price.html"
                    title="Whirlpool FP 263D Royal Triple Door 240 Litres Frost Free Refrigerator Price"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/whirlpool-fp-263d-protton-roy-new-2017.jpg"
                            alt="Whirlpool FP 263D Royal Triple Door 240 Litres Frost Free Refrigerator"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Whirlpool FP 263D Royal Triple Door 240 Litres Frost Free Refrigerator Price</p>
                </a></li>
                <li><a href="https://www.compareraja.in/lg-gl-b201amln-single-door-190-litres-direct-cool-refrigerator-price.html"
                    title="LG GL B201AMLN Single Door 190 Litres Direct Cool Refrigerator " class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/refrigerator/v1/LG-GL-B201AMLN-new-2017.jpg"
                            alt="LG GL B201AMLN Single Door 190 Litres Direct Cool Refrigerator " width="70"
                            height="145" />
                    </p>
                    <p class="product-txt">
                        LG GL B201AMLN Single Door 190 Litres Direct Cool Refrigerator
                    </p>
                </a></li>
            </ul>
            <p class="cat-title">
                Best Selling Washing Machines as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/bosch-wak24168in-7-kg-fully-automatic-front-loading-washing-machine-price.html"
                    title="Bosch WAK24168IN 7 Kg Fully Automatic Front Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/bosch-wak24168in-7-kg-hp.jpeg"
                            alt="Bosch WAK24168IN 7 Kg Fully Automatic Front Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Bosch WAK24168IN 7 Kg Fully Automatic Front Loading Washing Machine</p>
                </a></li>
<li><a href="https://www.compareraja.in/ifb-senorita-aqua-sx-6-5-kg-fully-automatic-front-loading-washing-machine-price.html"
                    title="IFB Senorita Aqua SX 6.5 kg Fully Automatic Front Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/ifb-senorita-aqua-sx-6-5-kg-hp.jpeg"
                            alt="IFB Senorita Aqua SX 6.5 kg Fully Automatic Front Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        IFB Senorita Aqua SX 6.5 kg Fully Automatic Front Loading Washing Machine</p>
                </a></li>
<li><a href="https://www.compareraja.in/samsung-ww60m206lmw-tl-6-kg-fully-automatic-front-loading-washing-machine-price.html"
                    title="Samsung WW60M206LMW TL 6 Kg Fully Automatic Front Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/samsung-ww60m206lmw-tl-6-kg-hp.jpeg"
                            alt="Samsung WW60M206LMW TL 6 Kg Fully Automatic Front Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Samsung WW60M206LMW TL 6 Kg Fully Automatic Front Loading Washing Machine</p>
                </a></li>
<li><a href="https://www.compareraja.in/lg-t7269nddl-6-2-kg-fully-automatic-top-loading-washing-machine-price.html"
                    title="LG T7269NDDL 6.2 Kg Fully Automatic Top Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/lg-t7269nddl-6-2-kg-hp.jpeg"
                            alt="LG T7269NDDL 6.2 Kg Fully Automatic Top Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        LG T7269NDDL 6.2 Kg Fully Automatic Top Loading Washing Machine</p>
                </a></li>
<li><a href="https://www.compareraja.in/haier-hwm60-10-6-kg-washer-dryer-fully-automatic-washing-machine-price.html"
                    title="Haier HWM60 10 6 kg Fully Automatic Top Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/haier-hwm60-10-6-kg-hp.jpeg"
                            alt="Haier HWM60 10 6 kg Fully Automatic Top Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Haier HWM60 10 6 kg Fully Automatic Top Loading Washing Machine</p>
                </a></li>
<li><a href="https://www.compareraja.in/whirlpool-superb-atom-60i-6-kg-semi-automatic-top-loading-washing-machine-price.html"
                    title="Whirlpool Superb Atom 60I 6 Kg Semi Automatic Top Loading Washing Machine"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/washingmachine/whirlpool-superb-atom-60i-6-kg-hp.jpeg"
                            alt="Whirlpool Superb Atom 60I 6 Kg Semi Automatic Top Loading Washing Machine"
                            width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Whirlpool Superb Atom 60I 6 Kg Semi Automatic Top Loading Washing Machine</p>
                </a></li>
            </ul>
            <p class="cat-title">
                Best Selling Laptops as on
                November 7, 2017</p>
            <ul class="bestsel">
                <li><a href="https://www.compareraja.in/apple-macbook-air-mqd32hn-a-price.html" title = "Apple MacBook Air MQD32HN/A"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/apple-macbook-air-mqd32hn-a-hp.jpeg"
                            alt="Apple MacBook Air MQD32HN/A" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Apple MacBook Air MQD32HN/A</p>
                </a></li>
<li><a href="https://www.compareraja.in/hp-15-be012tu-notebook-price.html" title = "HP 15-BE012TU Notebook"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/hp-15-be012tu-notebook-hp.jpeg"
                            alt="HP 15-BE012TU Notebook" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        HP 15-BE012TU Notebook</p>
                </a></li>
<li><a href="https://www.compareraja.in/lenovo-ideapad-320-80xh01jfin-laptop-price.html" title="Lenovo Ideapad 320 80XH01JFIN Laptop"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/lenovo-ideapad-320-80xh01jfin-laptop-hp.jpeg"
                            alt="Lenovo Ideapad 320 80XH01JFIN Laptop" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Lenovo Ideapad 320 80XH01JFIN Laptop</p>
                </a></li>
<li><a href="https://www.compareraja.in/dell-inspiron-15-3567-laptop-price.html" title="Dell Inspiron 15 3567 Laptop"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/dell-inspiron-15-3567-laptop-hp.jpeg"
                            alt="Dell Inspiron 15 3567 Laptop" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Dell Inspiron 15 3567 Laptop</p>
                </a></li>
<li><a href="https://www.compareraja.in/iball-exemplaire-compbook-laptop-price.html" title="iBall Exemplaire CompBook Laptop"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/iball-exemplaire-compbook-laptop-hp.jpeg"
                            alt="iBall Exemplaire CompBook Laptop" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        iBall Exemplaire CompBook Laptop</p>
                </a></li>
<li><a href="https://www.compareraja.in/acer-aspire-e5-575g-laptop-price.html" title="Acer Aspire E5-575G Laptop"
                    class="link">
                    <p class="product-pic">
                        <img src="https://www.compareprix.in/images/homeproductimg/bestselling/laptop/acer-aspire-e5-575g-laptop-hp.jpeg"
                            alt="Acer Aspire E5-575G Laptop" width="147" height="147">
                    </p>
                    <p class="product-txt">
                        Acer Aspire E5-575G Laptop</p>
                </a></li>
            </ul>
        </div>
        <div class="aboutsechome">
            <h3 class="abouttitle moveUp animated">
                About CompareRaja.in</h3>
            <p class="parabtm moveUp animated">
                CompareRaja.in is leading price comparison site in India established in July 2012.
                You can compare prices of categories like Mobiles, Tablets, Laptops, Cameras, Hard
                Disks, Printers, TVs, ACs, Refrigerators, Washing Machines, Microwave Ovens, Water
                Purifiers etc.
            </p>
            <p class="parabtm moveUp animated">
                CompareRaja's price comparison services can also be accessed through Mobile Apps.
                (Android, IOS and Windows) and Browser Extensions (Firefox, Chrome) which just adds
                to your convenience.
            </p>
            <p class="parabtm moveUp animated">
                In short, CompareRaja.in makes online shopping easy with a user-friendly interface
                which helps you to save time & money both.
            </p>
        </div>
    </div>
    <div class="clear ht-twenty">
    </div>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/homepage.js?v=0.01"></script>
    
    <script defer="defer" type="text/javascript" src='https://www.compareprix.in/scripts/jqueryautocompletenew.js?v=1.7'></script>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/slick.js?v=1.5"></script>
    <script type="text/javascript">
        var h = jQuery.noConflict(); h(document).ready(function () { h(".multiple-items").slick({ dots: !0, infinite: !0, speed: 1200, slidesToShow: 4, slidesToScroll: 1, autoplay: !0, autoplaySpeed: 2E3 }); h(".p-electr").slick({ dots: !0, infinite: !0, speed: 1200, slidesToShow: 5, slidesToScroll: 1, autoplay: !1, autoplaySpeed: 2E3 }); h('.slider').css({ 'opacity': '1' }) })
    </script>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/jquery.tabslet.min.js"></script>
    <script defer="defer" type="text/javascript" src="https://www.compareprix.in/scripts/initializers.js?v=0.3"></script>
    <script type="text/javascript">
        var j = jQuery.noConflict(); j(window).load(function () { $('#divscrollsearch').empty(); var lnk4 = 'https://www.compareraja.in/' + 'commonautocompletedata.ashx'; j("#ctl00_tophead_commonserach1_txtSearch").autocomplete(lnk4) })
    </script>
    <script type="text/javascript">
        function fnfocussearchbox(addobj) { if (addobj.value == "What are you looking for today? e.g. iPhone 6 plus") { addobj.value = "" } }
        function make_blank(addobj) { $('#ctl00_tophead_commonserach1_txtSearch').attr('placeholder', '') }
        function onblursearchbox(addobj) { if (addobj.value == "") { addobj.value = "What are you looking for today? e.g. iPhone 6 plus" } }
        function validateSearchParameter() { alert(document.getElementById('ctl00_tophead_commonserach1_txtSearch').value); if (document.getElementById('ctl00_tophead_commonserach1_txtSearch').value == "What are you looking for today? e.g. iPhone 6 plus") { return !1 } }
        function checkcurrentdata() {
            if (document.getElementById('ctl00_tophead_commonserach1_txtSearch').value == "What are you looking for today? e.g. iPhone 6 plus") { return !1 }
            else if (document.getElementById('ctl00_tophead_commonserach1_txtSearch').value == " ") { return !1 }
            return !0
        }
        function validateScripttag(o) { alert(o.value); var val = o.value }
        function onkeypressearchbox(addobj) { if (addobj.value != "") { var hdn; hdn = document.getElementById('ctl00_tophead_commonserach1_hdnsetviewall').value; document.getElementById('ctl00_tophead_commonserach1_hdnsetviewall').value = "" } }
    </script>
    <link rel="stylesheet" type="text/css" href="https://www.compareprix.in/stylesheet/homepage3.css?v=0.06" />

        </div>
        
<div class="clear ht-twenty">
</div>

<footer>
      <div class="foot-partner">
        <div class="foot-nav">
          <ul>
            <li><a href="https://www.compareraja.in/aboutus" title="About us">About Us</a> </li>            
            <li><a href="https://www.compareraja.in/contactus" title="Contact Us">Contact Us</a> </li>
            <li><a href="https://www.compareraja.in/terms-conditions" title="Terms">Terms</a> </li>
            <li><a href="https://www.compareraja.in/blog" title="Our Blog">Our Blog</a> </li>
            
            <li><a href="https://www.compareraja.in/all-brands.html" title="All Brands">All Brands</a> </li>
            <li><a href="https://www.compareraja.in/meet-the-team.htm" title="Meet The Team">Meet The Team</a></li>
          </ul>
        </div>
        <div class="footer-nav">
          <ul>
            <li class="our-app social-icons icon-circle icon-rotate list-unstyled list-inline"> <span>Our Apps: </span>
              <div class="socialicons"> 
                <a href="https://itunes.apple.com/in/app/compareraja-price-comparison/id1084702575?mt=8" target="_blank" title="Apple"><i class="fa fa-apple"></i></a>
                <a href="https://play.google.com/store/apps/details?id=com.ls.android.compararaja" target="_blank" title="Android"><i class="fa fa-android"></i></a>
                <a href="http://www.windowsphone.com/en-in/store/app/compareraja/475b9c39-191f-48c6-89bb-c3391ea3698a" target="_blank" title="Window"><i class="fa fa-windows"></i></a>
              </div>
            </li>
            <li class="social-icons icon-circle icon-rotate list-unstyled list-inline"> <span>Follow us: </span>
              <div class="socialicons">
                <a href="https://www.facebook.com/compareraja" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                <a href="https://www.twitter.com/compareraja" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                <a href="https://plus.google.com/+ComparerajaIndia" title="Google Plus" target="_blank"><i class="fa fa-google-plus"></i></a>
                <a href="https://pinterest.com/compareraja" title="Pintrest" target="_blank"><i class="fa fa-pinterest-square"></i></a>
              </div>
            </li>
          </ul>
        </div>
        <p class="dmca">
        <span class="dib">This website is</span>
        <a href="http://www.dmca.com/Protection/Status.aspx?ID=75eb2985-8cec-4eaa-abb7-fbdf998d855a" title="DMCA.com Protection Status" class="dmca-badge"> <img width="120" height="43" src="https://www.compareprix.in/images/DMCA_logo.png?ID=75eb2985-8cec-4eaa-abb7-fbdf998d855a&v=72" alt="DMCA.com Protection Status"></a> <script defer="defer" src="//images.dmca.com/Badges/DMCABadgeHelper.min.js"> </script>
        </p>
        <p>Made with &#10084; in India &nbsp;&nbsp;|&nbsp;&nbsp; &copy;2017 Logicserve Technologies Pvt. Ltd. Venture</p>
      </div>
    </footer>


<div class="clear">
</div>

             <div class="clear"></div>
             <!--Footer End-->
            <!--Login popup start here -->
            
              <div class="md-overlay">
            </div>
    </div>
    </form>
    <script type="text/javascript">
        $(window).scroll(function () {
            if (readCookie1('bannerhide') === 'true') { $('#spopup').hide() }
            else { $("#spopup").show("slow") } 
        }); function closeSPopup() { $('#spopup').hide('slow'); createCookie1('bannerhide', !0, 1) }
    </script>

      <!--remarketing code Start-->

<!--remarketing code End-->

 <div id="spopupaj" style="display: none;">
    <!-- popup close button -->
    <a class="close-pp" href="javascript:void(0);" onclick="return closeSPopup();"></a>
    <div class="add-content">
    
           <a href="https://www.amazon.in/gp/goldbox/ref=as_li_ss_tl?ie=UTF8&linkCode=ll2&tag=comparepromo-21&linkId=77b19ee3df28a7e5ae553059fe263220" target="_blank" rel="NOFOLLOW" >
            <img src="https://www.compareprix.in/images/advt/amazon-todays-deal-banner-300x250-v2.gif" alt="" width="300" height="250" /></a>
    </div>
</div>

 <!--bottomnotification start-->
    <!--bottomnotification end-->


</body>

<!-- Google Tag Manager (noscript) -->

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P7MLBBS"

height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<!-- End Google Tag Manager (noscript) -->  

  

<script type="text/javascript" >
    $(window).scroll(function () {
        if (readCookie1('bannerhide') === 'true') { $('#spopup').hide(); document.getElementById("sectionclose").style.display = 'none' }
        else { $("#spopup").show("slow") } 
    }); function closeSPopup() { $('#spopup').hide('slow'); createCookie1('bannerhide', !0, 1) }
    $(document).ready(function () { $('.closebn').click(function () { $('.bottomnotification').addClass("bz") }) })
</script>
        <script type="text/javascript" >
            function createCookie1(name, value, days) {
                if (days) { var date = new Date(); date.setTime(date.getTime() + (5 * 60 * 1000)); var expires = "; expires=" + date.toGMTString() }
                else var expires = ""; document.cookie = name + "=" + value + expires + "; path=/"
            }
            function readCookie1(name) {
                var nameEQ = name + "="; var ca = document.cookie.split(';'); for (var i = 0; i < ca.length; i++) { var c = ca[i]; while (c.charAt(0) == ' ') c = c.substring(1, c.length); if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length) }
                return null
            }
            function eraseCookie1(name) { createCookie1(name, "", -1) }
            function createCookieclose1(name, value, days) {
                if (days) { var date = new Date(); date.setTime(date.getTime() + (days * 2592000000)); var expires = "; expires=" + date.toGMTString() }
                else var expires = ""; document.cookie = name + "=" + value + expires + "; path=/"
            }
            function readCookieclose1(name) {
                var nameEQ = name + "="; var ca = document.cookie.split(';'); for (var i = 0; i < ca.length; i++) { var c = ca[i]; while (c.charAt(0) == ' ') c = c.substring(1, c.length); if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length) }
                return null
            }
            function eraseCookie1(name) { createCookieclose1(name, "", -1) }
</script>
</html>

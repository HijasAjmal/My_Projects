<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if(session_id() == '' || !isset($_SESSION)){session_start();}


?>

<!doctype html>
<html class="no-js" lang="en">
   <head>
        <title>SmartSP||Login</title>
        <meta charset="utf-8">
        <link rel="icon" href="images/web.png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
       <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">SmartSP</a>
          </div>
           <ul class="nav navbar-nav navbar-right">
            <?php

          if(isset($_SESSION['email'])){
            echo '<li><a href="account.php"><span class="glyphicon glyphicon-user"></span> My Account</a></li>';
            echo '<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Log Out</a></li>';
          }
          else{
            echo '<li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
          }
          ?>
      
      
    </ul>
          
      <ul class="nav navbar-nav">
            <li ><a href="#">Services</a></li>
            <li ><a href="about.php">About-us</a></li>
            <li ><a href="products.php">Products</a></li>
           <li ><a href="contact.php">Contact-us</a></li>
            
           
        </ul>

   
  </div>
</nav>



    <div class="row" style="margin-top:10px;">
      <div class="small-12">
        <p align="center">Your order placed in our database successfully. Congrats!</p>
        <p align="center">please check your spam in email for the receipt.</p>


        <footer style="margin-top:10px;">
           <p style="text-align:center; font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</p>
        </footer>

      </div>
    </div>
  </body>
</html>

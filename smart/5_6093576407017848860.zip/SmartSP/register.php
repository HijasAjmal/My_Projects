<?php
  //if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
  if(session_id() == '' || !isset($_SESSION)){session_start();}
  if (isset($_SESSION["username"])) {header ("location:index.php");}
?>

<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
        <title>SmartSP||Register</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
       <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">SmartSP</a>
          </div>
           <ul class="nav navbar-nav navbar-right">
            <?php

          if(isset($_SESSION['username'])){
            echo '<li><a href="account.php"><span class="glyphicon glyphicon-user"></span> My Account</a></li>';
            echo '<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Log Out</a></li>';
          }
          else{
            echo '<li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
          }
          ?>
      
      
    </ul>
          
      <ul class="nav navbar-nav">
            <li ><a href="#">Services</a></li>
            <li ><a href="about.php">About-us</a></li>
            <li ><a href="products.php">Products</a></li>
           <li ><a href="contact.php">Contact-us</a></li>
            
           
        </ul>

   
  </div>
</nav>


           <div class="container">
    <div class="row">
      <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <b><h3 class="panel-title">Sign-up here</h3></b>
        </div>
          <div class="panel-body">
            <form method="POST" action="insert.php" onsubmit="if(document.getElementById('agree').checked) { return true; } else { alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy'); return false; }">
                    <fieldset>
                <div class="form-group">
                    <input class="form-control" type="text" id="right-label" placeholder="Name" name="name" required placeholder="Enter Name" oninvalid="this.setCustomValidity('Enter your Name Here')"
    oninput="setCustomValidity('')"  >
                </div> 
              <div class="form-group">
                   <input class="form-control" type="email" id="right-label" placeholder="Email" name="email" required placeholder="Enter Name" oninvalid="this.setCustomValidity('Enter your Email Here')"
    oninput="setCustomValidity('')">
              </div>
              <div class="form-group">
                    <input class="form-control" type="text" id="right-label" placeholder="Mobile" name="mobile" maxlength="10" size="10" required placeholder="Enter Name" oninvalid="this.setCustomValidity('Enter your Mobile number Here')"
    oninput="setCustomValidity('')">
                </div>
              <div class="form-group">
                <input class="form-control" type="password" id="password" name="password" placeholder="Password" required placeholder="Enter Name" oninvalid="this.setCustomValidity('Enter your Password Here')"
    oninput="setCustomValidity('')">
              </div>
              <div class="form-group">
                <input class="form-control" type="password" id="confirm" name="password" placeholder="Confirm Password" required placeholder="Enter Name" oninvalid="this.setCustomValidity('Confirm your Password')"
    oninput="setCustomValidity('')">
              </div>
              <div class="checkbox">
                  <label>
                    <input type="checkbox" name="checkbox" value="check" id="agree" /> I agree to the <a href="#">Terms and Conditions</a>
                  </label>
                </div>
              <input class="btn btn-lg btn-success btn-block" type="submit" value="Signup" onclick="Validate()">
            </fieldset>
              </form>
              <script type="text/javascript">
        function Validate() {
        var password = document.getElementById("password").value;
        var confirm = document.getElementById("confirm").value;
        if(!confirm)
        else if (password != confirm) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>
                   
          </div>
      </div>
    </div>
  </div>
</div>

    <div class="row" style="margin-top:10px;">
      <div class="small-12">

        <footer align="center">
           <p style="text-align:center; font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</p>
        </footer>

      </div>
    </div>




    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>

<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if(session_id() == '' || !isset($_SESSION)){session_start();}

if(isset($_SESSION["email"])){

        header("location:index.php");
}

?>

<!doctype html>
<html class="no-js" lang="en">
   <head>
        <title>SmartSP||Login</title>
        <meta charset="utf-8">
        <link rel="icon" href="images/web.png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
       <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">SmartSP</a>
          </div>
           <ul class="nav navbar-nav navbar-right">
            <?php

          if(isset($_SESSION['username'])){
            echo '<li><a href="account.php"><span class="glyphicon glyphicon-user"></span> My Account</a></li>';
            echo '<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Log Out</a></li>';
          }
          else{
            echo '<li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
          }
          ?>
      
      
    </ul>
          
      <ul class="nav navbar-nav">
            <li ><a href="#">Services</a></li>
            <li ><a href="about.php">About-us</a></li>
            <li ><a href="products.php">Products</a></li>
           <li ><a href="contact.php">Contact-us</a></li>
            
           
        </ul>

   
  </div>
</nav>

 



    
     
           <div class="container">
    <div class="row">
      <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <b><h3 class="panel-title">Login here</h3></b>
        </div>
          <div class="panel-body">
            <form method="POST" action="verify.php">
                    <fieldset>
                <div class="form-group">
                   <input class="form-control" type="email" id="right-label" placeholder="example@gmail.com" name="email">
              </div>
              <div class="form-group">
                <input class="form-control" type="password" id="right-label" name="password" placeholder="********">
              </div>
              <input class="btn btn-lg btn-success btn-block" type="submit" value="Login">
            </fieldset>
              </form>
                      <hr/>
                    <center><h4>OR</h4></center>
                    <input class="btn btn-lg btn-facebook btn-block" type="submit" value="Login via facebook">
          </div>
      </div>
    </div>
  </div>
</div>






    <div class="row" style="margin-bottom:400px; text-align: center;">
      <div class="small-12">

        <footer>
           <div style="padding-left: 0px;    font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</div>
        </footer>

      </div>
    </div>
    
  </body>
</html>




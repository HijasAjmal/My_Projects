-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2017 at 12:55 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartsp`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` varchar(100) NOT NULL,
  `order_amount` float NOT NULL,
  `order_name` varchar(100) NOT NULL,
  `ordership_address1` varchar(100) NOT NULL,
  `ordership_address2` varchar(100) NOT NULL,
  `order_city` varchar(100) NOT NULL,
  `order_state` varchar(100) NOT NULL,
  `order_pin` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `order_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_name` text NOT NULL,
  `product_detail` varchar(1000) NOT NULL,
  `product_img_name` varchar(60) NOT NULL,
  `quantity` int(100) NOT NULL,
  `price` float NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `offer_expire` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_code`, `product_name`, `product_detail`, `product_img_name`, `quantity`, `price`, `product_category`, `offer_expire`) VALUES
(0, 'SP100', 'San Disk pendrive', '    USB 2.0|8 GB\r\nPlastic\r\nFor Laptop, Tablet, Desktop Computer\r\nColor:Black', 'sandisk', 10, 400, 'pendrive', '2017-11-20 00:00:00.000000'),
(1, 'SP101', 'SanDisk Ultra Dual Drive', 'Small and stylish, this pendrive from SanDisk feels nice in your hand and makes transferring just about anything from almost anywhere fast and easy. Be it a movie you want to watch on the phone or pictures you want to transfer and photoshop, you have no trouble with this SanDisk pendrive. ', 'sandisk2', 5, 600, 'pendrive', '2017-11-21 21:20:29.000000');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`email`) VALUES
('muhammadshahidraficp@gmail.com'),
('muhammadshahidraficp@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`) VALUES
(0, 'kavya', 'kavyakamalkhd@gmail.com', '1234567890', '12162416'),
(0, 'shahid', 'muhammadshahidraficp@gmail.com', '7012270577', '1234567890'),
(0, 'MUSTHAFA MAMMASSAN MOOSAN', 'muhammedmsr@gmail.com', '8547404631', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();} for php 5.4 and above

if(session_id() == '' || !isset($_SESSION)){session_start();}


?>

<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/web.png">
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>SmartSP || About Us</title>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
  </head>
  <body>

   <nav  class="navbar navbar-static-top navbar-default navbar-custom1">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
<img border="1" alt="SmartSP" src="images/web.png" width="100" height="100">
</a>

    <ul class="nav navbar-nav">
          <li><a href="about.php">About-us</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="cart.php">View Cart</a></li>
          
          <li><a href="contact.php">Contact</a></li>
          
      </ul>

    <ul class="nav navbar-nav navbar-right">
          
          <?php
    
          if(isset($_SESSION['email'])){
            echo '<li><a href="account.php">My Account</a></li>';
            echo '<li><a href="orders.php">My Orders</a></li>';
            echo '<li><a href="logout.php">Log Out</a></li>';
          }
          else{
            echo ' <li ><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
            echo '<li ><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
          }
          ?>
    </ul>
  </div>
</nav>



<style>
  .jumbotron {
      background-color:#BA4D0E;
      color: #fff;
      padding: 100px 25px;
  }
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #f4511e;
      font-size: 50px;
  }
  .logo {
      color: #f4511e;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
     background-image: none;
     color: #f4511e;
  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
  }
  .item span {
      font-style: normal;
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
  }
  </style>


       
      

    <div class="jumbotron text-center">
  <h1>SmartSP</h1>
  <p><i>Make Something Different!!!</i></p>
   <p>SmartSP is a E-Commerce company headquartered in Kozhikode, India. It was founded in November 2017 by Team future.</p>
 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-shopping-cart logo-small"></span>
      <h3><b>Shared Purchase</b></h3>
      <p>Find your purchasing partner......</p>
      <p>SmartSP mainly aims to popularize combo offers by providing shared purchase scheme</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo-small"></span>
      <h3><b>Wholesale</b></h3>
      <p>Do you want goods in large quantities??</p>
      <p>acting as an agent or broker in buying merchandise for, or selling merchandise to, such persons or companies. </p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-stats logo-small"></span>
      <h3><b>Compare Product</b></h3>        
      <p>Shopping online? A little research can save you a lot of money. Even when you know what you want</p>
      <p>It is worth checking one of the many available price and product comparison sites before making your purchase.</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-briefcase logo-small"></span>
      <h3><b>Part-Time JOb</b></h3>        
      <p>There is No limit or Target.You can work as much as you can.As this is a Part time Job.</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-piggy-bank logo-small"></span>
      <h3><b>Earnings</b></h3>        
      <p>Get the best margins in the market.Service more, earn more!</p>
      <p>Set the discount you want to apply. Never lose a sale again!</p>
    </div>
    <div class="col-sm-4">
      <span class=" glyphicon glyphicon-headphones logo-small"></span>
      <h3><b>24x7 Support</b></h3>        
      <p>we offers you 24hr active customer service</p>
      <p>Email us at support@smartsp.com</p>
    </div>
  </div>
</div>



    
        <footer>
           <h4 style="text-align:center; font-size:0.8em;">&copy; SmartSP. All Rights Reserved.</h4>
        </footer>

      </div>
    </div>







    <script src="js/vendor/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
  </body>
</html>

var btn = document.getElementById("estorebutton");
var modal = document.getElementById("popupform");
/*$('#headingcancel').click(function(){
	$('#popupform').hide();
});*/

$(document).ready(function(){
    // Code to be executed
    alert("Hello World!");
});

function navigationmenuclick(tabName, btn) {
	// body...
	var i;
    var x = document.getElementsByClassName("mainpage");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    document.getElementById(tabName).style.display = "block";
}

function myFunction(){
  document.getElementById("Home").style.display="block";
  document.getElementById("fp").style.display="block";
}




function button(item){


	if (document.getElementById(item).style.display === "none"){
		//document.getElementById(item).style.display="block";
		$('#'+item).fadeIn();
        $('#'+item).fadeIn("xslow");
        $('#'+item).fadeIn(1000);
	}
	else{
		document.getElementById(item).style.display="none";
		/*$('#'+item).fadeOut();
        $('#'+item).fadeOut("slow");
        $('#'+item).fadeOut(3000);*/
	}
}




// When the user clicks the button, open the modal
function estoreclicks() {
    //modal.style.display = "block";
    document.getElementById("popupform").style.display = "block";

}



// When the user clicks anywhere outside of the modal, close it
window.addEventListener("click", function(event) {
	if (event.target === modal) {

        document.getElementById("popupform").style.display = "none";

    }
});



function headingcancel(){
	document.getElementById("popupform").style.display = "none";
}


//global variables
var str = "How to recieve Divine Healing";
var str1 = "This book is a must read fot everyone that desire the healing power of...";
var head = [];head[0] = head[1] = head[2] = head[3] = head[4] = head[5] = str;
var dcs = [];dcs[0] = dcs[1] = dcs[2] = dcs[3] = dcs[4] = dcs[5] = str1;


//Function for loading main default contents in the page
function myFunction(){
	$('#Home').css('display','block');
	$('#a>div').css("background-image", "url('./images/Salvation_downarrow.png')");

}

//Fuction for controlling navigation button actions
function navigationmenuclick(tabName, t1) {
    var x = $(".mainpage");
    for (var i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    var x1 = $(".buttons");
    for (var i = 0; i < x1.length; i++) {
    	if(i == t1){
    		$('#'+t1).css({'border-bottom':'none','position':'relative', 'backgroundImage':'', 'background-color': 'white'}); 
    		continue;
    	}
    	x1[i].style.backgroundImage = "url('./images/Salvation_menuback.png')";
    	$('#'+i).css({'border-bottom':'1px solid gainsboro'}); 
    } 
    $('#'+tabName).css('display','block');
}


//Function for controlling the actions of buttons in the sidebar
function button(item,btid,idb){
	if ( $('#'+item).css('display')==='none'){
		$('#'+item).fadeIn();
    $('#'+item).fadeIn("xslow"); 
    $('#'+item+'>div>h3').text(head[idb]);
    $('#'+item+'>div>p').text(dcs[idb]);
    $('.sidebarbutton>div').css("background-image", "url('./images/Salvation_rightarrow.png')");
    $('#'+btid+'>div').css("background-image", "url('./images/Salvation_downarrow.png')");
	}
	else{
		$('#'+btid+'>div').css("background-image", "url('./images/Salvation_rightarrow.png')");
		$('#'+item).fadeOut();
    $('#'+item).fadeOut("xslow");
    
	}
  	var j;
  	var sidebg = $('.sidebarspace');
  	for (j = 0; j < sidebg.length; j++) {
      sidebg[j].style.display = "none";
    }
}


 		

// When the user clicks the button, open the modal
function estoreclicks(estoreid) {

	//display the popup-form 
    $('#popupform').css('display','block');

    //hide the popup-form When user click the submit button
    $('#headingsubmit').click(function(){ 

    //takes the values from input fields
    if(estoreid === 'fp'){
        head[0] =  $("#headingform").val();
        dcs[0] = $("#dcsform").val();
    }else if(estoreid === 'sm1'){
    	head[1] =  $("#headingform").val();
    	dcs[1] = $("#dcsform").val();
    }else if(estoreid === 'sm2'){
    	head[2] =  $("#headingform").val();
    	dcs[2] = $("#dcsform").val();
    }else if(estoreid === 'sm3'){
		head[3] =  $("#headingform").val();
        dcs[3] = $("#dcsform").val();
    }else if(estoreid === 'sm4'){
    	head[4] =  $("#headingform").val();
        dcs[4] = $("#dcsform").val();
    }else if(estoreid === 'sm5'){
        head[5] =  $("#headingform").val();
        dcs[5] = $("#dcsform").val();
    }
    $("#popupform").css('display', 'none');

    //display the values from input fields to corresponding form attributes
    if(estoreid === 'fp'){
        $('#'+estoreid+'>div>h3').text(head[0]);
        $('#'+estoreid+'>div>p').text(dcs[0]);
    }else if(estoreid === 'sm1'){
        $('#'+estoreid+'>div>h3').text(head[1]);
        $('#'+estoreid+'>div>p').text(dcs[1]);
    }else if(estoreid === 'sm2'){
        $('#'+estoreid+'>div>h3').text(head[2]);
        $('#'+estoreid+'>div>p').text(dcs[2]);
    }else if(estoreid === 'sm3'){
        $('#'+estoreid+'>div>h3').text(head[3]);
        $('#'+estoreid+'>div>p').text(dcs[3]);
    }else if(estoreid === 'sm4'){
        $('#'+estoreid+'>div>h3').text(head[4]);
        $('#'+estoreid+'>div>p').text(dcs[4]);
    }else if(estoreid === 'sm5'){
        $('#'+estoreid+'>div>h3').text(head[5]);
        $('#'+estoreid+'>div>p').text(dcs[5]);
    }
    
    //make the parameter value as null
    estoreid = null;
        
    });

}


//function for slider-----------------------------------------
$(document).ready(function(){

	//array for storing the slider images
	var slides= [];	slides[0]= './images/Salvation_mainimg.png';
	slides[1]= './images/1.jpg';slides[2]= './images/2.jpg';slides[3]= './images/3.jpg';
	slides[4]= './images/4.jpeg';slides[5]= './images/5.jpg';

	//necessery variables for slider 
	var intervel=3000;
	var pause = false;
	var slideIndex=0;
	var imageLimit= slides.length-1;

	//slide navigator
	var slidePoints= [];

	//creating sliding dots according to the length of images
	for(var i=0; i<imageLimit+1; i++)
	{
		slidePoints[i]='<div class="points"></div>';
		$('.slidingpoints').append(slidePoints[i]);
	}

	//create an image element in container for display images
	$('.container').html('<img src=' + slides[slideIndex] +'>');
	$('.container > img').addClass('slidingimg');

	//make dots coloring coresponding to images
	$( '.points' ).eq(slideIndex).addClass('active');

	timingRun = setInterval(function(){ autoSlides();}, intervel);

	//function for auto-slider
	function autoSlides (){
		if(pause === false){
			$( '.points' ).eq(slideIndex).removeClass('active');
			slideIndex++;
			if(slideIndex>imageLimit){
				slideIndex=0;
			}
			$('.container').animate({ marginLeft:"-710px"},function () {
				$('.container').fadeOut('fast').animate({marginLeft:"0px"},function(){
					$('.container').fadeIn(1000);	
					$('.container').html('<img src=' + slides[slideIndex] +'>');
					$('.container > img').addClass('slidingimg');
					$( '.points' ).eq(slideIndex).addClass('active');
				});
			
			});
		}
	}

	//next button action
	$('.nextb>img').click(function(){
		$( '.points' ).eq(slideIndex).removeClass('active');
		slideIndex++;
		if(slideIndex>imageLimit)
		{
			slideIndex=0;
		}
		$('.container').animate({ marginLeft:"-710px"},function () {
			$('.container').fadeOut();
			$('.container').animate({marginLeft:"0px"},function(){
				$('.container').fadeIn();
				$('.container').html('<img src=' + slides[slideIndex] +'>');
				$('.container > img').addClass('slidingimg');
				$( '.points' ).eq(slideIndex).addClass('active');
			});
			
		});
		sliderTiming();
	});


	//previous button action
	$('.prevb>img').click(function(){
		$( '.points' ).eq(slideIndex).removeClass('active');
		slideIndex--;
		if(slideIndex<0)
		{
			slideIndex=imageLimit;
		}
		$('.container').animate({ marginLeft:"710px"},function () {
			$('.container').fadeOut();
			$('.container').animate({marginLeft:"0px"},function(){
				$('.container').fadeIn();
				$('.container').html('<img src=' + slides[slideIndex] +'>');
				$('.container > img').addClass('slidingimg');
				$( '.points' ).eq(slideIndex).addClass('active');
			});
			
		});
		sliderTiming();
	});

	//dots behaviour and action on the same
	$('.points').click(function () {
		$( '.points' ).eq(slideIndex).removeClass('active');
		slideIndex= $(this).index();
		$('.container').animate({ marginLeft:"-710px"},function () {
			$('.container').fadeOut();
			$('.container').animate({marginLeft:"0px"},function(){
				$('.container').fadeIn();
				$('.container').html('<img src=' + slides[slideIndex] +'>');
				$('.container > img').addClass('slidingimg');
				$( '.points' ).eq(slideIndex).addClass('active');
			});
			
		});
		sliderTiming();
	});

	//reset the time interval
	function sliderTiming() {
		clearInterval(timingRun);
		timingRun = setInterval(function() { autoSlides(); },intervel);
	}

	//pause When mouse on slider or continue
	$(".container").mouseenter(function(){
    	pause = true;
	}).mouseleave(function(){
    	pause = false;
	});

	//hide the popup-form When click the cancel button
	$("#headingcancel").click(function(){
    	$("#popupform").css('display', 'none');
    });
});
function navigationmenuclick(tabName) {
	// body...
		var i;
    var x = document.getElementsByClassName("mainpagebg");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    document.getElementById(tabName).style.display = "block";
}
function myFunction(){
  document.getElementById("Home").style.display="block";
}
function next(){
	alert("Sorry");
}
function button(item){
	if (document.getElementById(item).style.display==="none") {
			document.getElementById(item).style.display="block";
	}else{
		document.getElementById(item).style.display="none";
	}

}

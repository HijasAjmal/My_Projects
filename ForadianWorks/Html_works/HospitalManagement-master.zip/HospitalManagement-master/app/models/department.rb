class Department < ActiveRecord::Base
end

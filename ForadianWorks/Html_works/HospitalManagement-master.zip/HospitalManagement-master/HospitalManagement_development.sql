-- MySQL dump 10.15  Distrib 10.0.36-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: HospitalManagement_development
-- ------------------------------------------------------
-- Server version	10.0.36-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (6,'Dental','2018-12-21 05:24:06','2018-12-21 05:24:06'),(7,'Casuality','2018-12-21 05:24:14','2018-12-21 05:24:15'),(8,'Anesthesiology & Perioperative Care','2018-12-21 06:57:05','2018-12-21 06:57:05'),(9,'Dermatology','2018-12-21 06:57:22','2018-12-21 06:57:23'),(10,'Emergency Medicine','2018-12-21 06:57:35','2018-12-21 06:57:35'),(11,'Cardiology','2018-12-21 06:57:54','2018-12-21 06:57:55'),(12,'Endocrinology','2018-12-21 06:58:03','2018-12-21 06:58:03'),(13,'Immunology','2018-12-21 06:58:13','2018-12-21 06:58:13'),(14,'Gastroenterology','2018-12-21 06:58:22','2018-12-21 06:58:22'),(15,'Neurological Surgery','2018-12-21 06:58:41','2018-12-21 06:58:42'),(16,'Neurology','2018-12-21 06:58:50','2018-12-21 06:58:50'),(17,'Gynecology','2018-12-21 06:58:58','2018-12-21 06:58:58'),(18,'Nuclear Medicine','2018-12-21 06:59:46','2018-12-21 06:59:47'),(19,'Vascular/Interventional Radiology','2018-12-21 07:00:01','2018-12-21 07:00:01'),(20,'Critical Care','2018-12-21 07:00:11','2018-12-21 07:00:11'),(21,'Nephrology','2018-12-21 07:00:29','2018-12-21 07:00:29'),(22,'Hematology/Oncology','2018-12-21 07:00:48','2018-12-21 07:00:48'),(23,'Infectious Diseases','2018-12-21 07:01:03','2018-12-21 07:01:03');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `qualifications` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (16,'Hijas','Ajmal','Ajmal','8907018654','Hijasajmal@gmail.com','Hijas','05/08/1995','Indian','Male','B-Tech','1-year','D0001','2018-12-17 05:23:21','2018-12-17 05:23:21'),(34,'Hijas','','Ajmal','8907018654',NULL,'','','India','Hijas Ajmal','','','','2018-12-18 04:30:39','2018-12-18 04:30:39'),(35,'Akku','Aji','Binu','8907018654',NULL,'ADA','05/08/1998','India','Hijas Ajmal','M-Tech','2','D006','2018-12-18 04:56:59','2018-12-18 04:56:59'),(38,'Dilkas','','Akmal','6765675678','dilkasakmal@gmail.com','nil','05/08/1995','India','Male','B-Tech','2','D006','2018-12-18 09:43:01','2018-12-18 09:43:01'),(97,'Hijas','','Ajmal',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'D006','2018-12-21 05:53:47','2018-12-21 05:53:47'),(98,'Hijas','','Ajmal',NULL,'Hijasajmal@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'D006','2018-12-21 05:54:04','2018-12-21 05:54:04'),(99,'Hijas','','Ajmal',NULL,'Hijasajmal@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'D006','2018-12-21 05:58:32','2018-12-21 05:58:32'),(103,'Hijas','','Ajmal',NULL,'Hijasajmal@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'D006','2018-12-21 09:04:09','2018-12-21 09:04:09');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blood_group` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Hijas','Akku','Ajmal','8907018654','Hijasajmal@gmail.com','05/08/1995','Pevungattil (h), Akkaparamba (po), Puliyacode, Malappuram (dt), kerala 673641','Hijas Ajmal','B +ve','nil','2018-12-18 10:13:08','2018-12-18 10:13:08'),(8,'Hijas','','Ajmal',NULL,'Hijasajmal@gmail.com',NULL,NULL,NULL,NULL,NULL,'2018-12-19 10:07:21','2018-12-19 10:07:21'),(9,'q','w','r',NULL,'Hijasajmal@gmail.com',NULL,NULL,NULL,NULL,NULL,'2018-12-19 11:10:06','2018-12-19 11:10:06');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20181214101939'),('20181214103027'),('20181214103036');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_record_id` int(11) DEFAULT NULL,
  `user_record_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_token` int(50) DEFAULT NULL,
  `confirmed` int(1) DEFAULT NULL,
  `remember_token` int(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `profile_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12,'Hijas','Ajmal','Aji','8907018654','Hijasajmal@gmail.com','.virus','A001',16,'Admin',NULL,1,NULL,'2018-12-17 05:23:00','2018-12-17 05:24:21',1),(32,NULL,NULL,NULL,NULL,NULL,'Hijas@U34','Hijas@U32',34,'Doctor',NULL,1,NULL,'2018-12-18 04:30:39','2018-12-18 04:30:40',1),(33,NULL,NULL,NULL,NULL,NULL,'Akku@U35','Akku@U33',35,'Doctor',NULL,NULL,NULL,'2018-12-18 04:56:58','2018-12-18 04:56:59',1),(34,NULL,NULL,NULL,NULL,NULL,'Hijas@U1','Hijas@U34',1,'Patient',NULL,1,NULL,'2018-12-18 05:05:06','2018-12-18 05:05:06',1),(37,'Apple','a','b','8907018654','hijasajmal@gmail.com','Apple@A37','A0037',NULL,'Admin',30,NULL,NULL,'2018-12-18 08:52:49','2018-12-18 08:52:49',1),(38,'a','b','c','8907018654','Hijasajmalaji@gmail.com','a@A38','A0038',NULL,'Admin',0,NULL,NULL,'2018-12-18 08:55:33','2018-12-18 08:55:33',1),(111,'Kali','','Linux',NULL,'hijas@foradian.com','Kali@A111','A00111',NULL,'Admin',NULL,1,NULL,'2018-12-19 10:02:06','2018-12-19 10:02:06',1),(112,NULL,NULL,NULL,NULL,NULL,'Hijas@U8','Hijas@U112',8,'Patient',0,NULL,NULL,'2018-12-19 10:07:21','2018-12-19 10:07:21',1),(116,NULL,NULL,NULL,NULL,NULL,'q@U9','q@U116',9,'Patient',0,NULL,NULL,'2018-12-19 11:10:05','2018-12-19 11:10:06',1),(126,NULL,NULL,NULL,NULL,NULL,'Hijas@U103','Hijas@U126',103,'Doctor',0,NULL,NULL,'2018-12-21 09:04:09','2018-12-21 09:04:09',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-21 14:47:20

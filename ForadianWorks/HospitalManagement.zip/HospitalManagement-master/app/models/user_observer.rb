class UserObserver < ActiveRecord::Observer

end

class Doctors < ActiveRecord::Base
  has_many :users, :as => :user_record
end

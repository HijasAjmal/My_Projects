class PatientsController < ApplicationController
end

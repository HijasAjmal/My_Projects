class SessionsController < ApplicationController
  def create
    # ...
    session[:current_user_id] = @user.id
    # ...
  end

  def destroy
    session[:current_user_id] = nil
    redirect_to("/")
  end

  def signin
    @user = Users.find(:first, :conditions => { :user_name => params[:user_name] , :password => params[:password]})
    if @user.nil?
      flash[:notice] = 'User Name or Password incorrect.....!'
      redirect_to :controller => :sessions
    elsif @user.confirmed == 1
      session[:current_user_id] = @user.id
      redirect_to("/users")
    else
      flash[:notice] = 'Please check your email..!'
      redirect_to :controller => :sessions
    end
  end
end

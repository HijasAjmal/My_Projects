class Room < ActiveRecord::Base
  belongs_to :departments
  has_many :beds, :dependent => :destroy
  validates_presence_of :no_of_beds
end

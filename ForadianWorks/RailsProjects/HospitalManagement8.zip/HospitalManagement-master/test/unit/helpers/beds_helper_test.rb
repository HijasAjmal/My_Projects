require 'test_helper'

class BedsHelperTest < ActionView::TestCase
end

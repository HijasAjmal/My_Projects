class Slot < ActiveRecord::Base
  belongs_to :timeslots
end

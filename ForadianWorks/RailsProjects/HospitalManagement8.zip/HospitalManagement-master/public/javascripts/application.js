// Place your application-specific JavaScript functions and classes here
// This file is automatically included by javascript_include_tag :defaults
function load_doctor(msg){
  alert(msg);
  $("#dropdownd").css('display', 'block');
}
function load_view(){
  $("#timeslotview").css('display', 'block');
}

function show_group_popup() {
  $('#groups_show').show();
  win = new Window({title: "Share This", width:200, height:150, destroyOnClose: true, recenterAuto:false});
  win.setContent('groups_show',true,true);
  win.show();
}

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '65c8d0afe43dd573c6e5b9d5388d5d31d097fc35faaafaaae60c0e7ef5200369f782f59cebbb0ddd82d83a2ebadfaafbcbcf01edaa74d299dc85de015ddbeba0';

-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2018 at 05:30 PM
-- Server version: 10.0.36-MariaDB-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SBlog_development`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_user_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `content`, `comment_user_id`, `post_id`, `created_at`, `updated_at`) VALUES
(35, 'good', 38, 12, '2018-12-10 09:50:23', '2018-12-10 09:50:45'),
(36, 'good', 38, 13, '2018-12-10 09:50:38', '2018-12-10 09:50:38'),
(37, 'good', 38, 14, '2018-12-10 09:50:59', '2018-12-10 09:50:59'),
(38, 'nice', 35, 12, '2018-12-10 09:51:11', '2018-12-10 09:51:11'),
(39, 'nice Article', 35, 13, '2018-12-10 09:51:25', '2018-12-10 09:51:25'),
(40, 'nice', 35, 14, '2018-12-10 09:51:30', '2018-12-10 09:51:30'),
(41, 'good one1', 36, 12, '2018-12-10 09:51:46', '2018-12-11 05:18:24'),
(42, 'sadfsffd', 36, 13, '2018-12-10 09:51:52', '2018-12-10 09:51:52'),
(45, 'frsdsa', 36, 14, '2018-12-11 05:18:45', '2018-12-11 05:18:45');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publisher` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `publisher`, `post_user_id`, `created_at`, `updated_at`) VALUES
(12, 'Operating Systems1', 'An operating system (OS) is system software that manages computer hardware and software resources and provides common services for computer programs.', 'Hijas', 36, '2018-12-10 09:48:00', '2018-12-11 05:17:57'),
(13, 'Cryptography', 'Cryptography or cryptology (from Ancient Greek: κρυπτός, translit. kryptós \"hidden, secret\"; and γράφειν graphein, \"to write\", or -λογία -logia, \"study\", respectively) is the practice and study of techniques for secure communication in the presence of thi', 'Foradian', 35, '2018-12-10 09:49:11', '2018-12-10 09:49:11'),
(14, 'Relational Databases', 'A relational database is a set of formally described tables from which data can be accessed or reassembled in many different ways without having to reorganize the database tables. The standard user and application programming interface (API) of a relation', 'Technodrills', 38, '2018-12-10 09:50:00', '2018-12-10 09:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `schema_migrations`
--

CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schema_migrations`
--

INSERT INTO `schema_migrations` (`version`) VALUES
('20181207051810'),
('20181207054315'),
('20181207054743'),
('20181207054808');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(3) NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` text CHARACTER SET utf16 COLLATE utf16_unicode_ci,
  `confirmation_token` int(50) DEFAULT NULL,
  `confirmed` int(1) DEFAULT '0',
  `remember_token` int(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `confirmation_token`, `confirmed`, `remember_token`, `created_at`, `updated_at`) VALUES
(35, 'Hijas@foradian.com', 'foradian', NULL, 1, NULL, '2018-12-10 04:12:21', '2018-12-10 04:12:48'),
(36, 'Hijasajmal@gmail.com', '.virus', NULL, 1, NULL, '2018-12-10 04:13:08', '2018-12-10 04:13:28'),
(38, 'technodrills@gmail.com', 'techbird', NULL, 1, NULL, '2018-12-10 04:16:34', '2018-12-10 04:16:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schema_migrations`
--
ALTER TABLE `schema_migrations`
  ADD UNIQUE KEY `unique_schema_migrations` (`version`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

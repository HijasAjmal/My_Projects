class Posts < ActiveRecord::Base
end

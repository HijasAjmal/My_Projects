require 'securerandom'
class UserController < ApplicationController

  def signup
    if params[:password] != params[:s_password]
      redirect_to :controller => :user
      flash[:notice] = 'Password different.....'
    else
      @user = User.find(:first, :conditions => { :email => params[:email]})
      if @user.nil?
        @user = User.create(:email => params[:email], :password => params[:password], :confirmation_token => SecureRandom.hex)
        redirect_to :controller => :sessions
      else
        flash[:notice] = 'Email Already exist in our database.....'
        redirect_to :controller => :user
      end
    end
  end
end

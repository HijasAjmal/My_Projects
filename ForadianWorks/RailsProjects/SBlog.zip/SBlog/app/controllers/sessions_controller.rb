require 'securerandom'
class SessionsController < ApplicationController

  @@rm_p = nil
  def create
    # ...
    session[:current_user_id] = @user.id
    # ...
  end
  

  def destroy
    session[:current_user_id] = nil
    redirect_to("/")
  end

  def signin
    @user = User.find(:first, :conditions => { :email => params[:email] , :password => params[:password]})
    if @user.nil?
      flash[:notice] = 'User Name or Password incorrect.....!'
      redirect_to :controller => :sessions
    elsif @user.confirmed == 1
      session[:current_user_id] = @user.id
      redirect_to("/")
    else
      flash[:notice] = 'Please check your email..!'
      redirect_to :controller => :sessions
    end
  end

  def confirm
    @user = User.find(:first, :conditions => { :confirmation_token => params[:id]})
    if @user.nil?
      flash[:notice] = 'This link is not valid..!'
    else
      @user.update_attributes(:confirmation_token => nil, :confirmed => 1)
      flash[:notice] = 'successfully verified your account..!'
      redirect_to :controller => :sessions
    end
  end



  def changepwd
    @user = User.find(:first, :conditions => { :remember_token => params[:id]})
    if @user.nil?
      flash[:notice] = 'This link is not valid..!'
      print "Hello World"
      redirect_to :controller => :sessions
    else
      @user.update_attributes(:password => params[:password], :remember_token => nil)
      flash[:notice] = 'successfully updated your account password..!'
      redirect_to :controller => :sessions
    end
  end

  def forget
    @user = User.find(:first, :conditions => { :email => params[:email]})
    if @user.nil?
      flash[:notice] = 'This email is not exist in our database..!'
      redirect_to :controller => :sessions
    else
      @user.update_attributes(:remember_token => SecureRandom.hex)
      UserMailer.deliver_password_email(@user)
      flash[:notice] = 'Password reset link is in your email..!'
      redirect_to :controller => :sessions
    end
  end
end

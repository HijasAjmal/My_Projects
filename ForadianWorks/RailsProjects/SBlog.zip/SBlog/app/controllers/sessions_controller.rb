class SessionsController < ApplicationController
  def create
    # ...
    session[:current_user_id] = @user.id
    # ...
  end
  def index


  end

  def destroy
    session[:current_user_id] = nil
    redirect_to("/")
  end

  def signin
    @user = User.find(:first, :conditions => { :email => params[:email] , :password => params[:password]})
    if @user.nil?
      flash[:notice] = 'User Name or Password incorrect.....!'
      redirect_to :controller => :sessions
    elsif @user.confirmed == 1
      session[:current_user_id] = @user.id
      redirect_to("/")
    else
      flash[:notice] = 'Please check your email..!'
      redirect_to :controller => :sessions
    end
  end

  def confirm
    @user = User.find(:first, :conditions => { :confirmation_token => params[:id]})
    if @user.nil?
      flash[:notice] = 'This link is not valid..!'
    else
      @user.update_attributes(:confirmation_token => nil, :confirmed => 1)
      flash[:notice] = 'successfully verified your account..!'
      redirect_to :controller => :sessions
    end
  end

  def forget_p
    
  end
end

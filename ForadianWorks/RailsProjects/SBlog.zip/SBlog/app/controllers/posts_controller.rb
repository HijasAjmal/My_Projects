class PostsController < ApplicationController

  before_filter :first_rule,
    :only => [:edit, :destroy]


  def first_rule
    @post = Post.find(params[:id])

  end
  def index
    @posts = Post.all
  end

  def show
    ######################
  end

  def new
    @post = Post.new
  end

  def edit
    #####################
  end

  def create
    @post = Post.new(params[:post])
      if @post.save
        redirect_to("/")
      end
  end

  def update
    @post = Post.find(params[:id])
      if @post.update_attributes(params[:post])
        redirect_to("/")
      else
        format.html { render :action => "edit" }
      end
  end

  def destroy
    @post.destroy
    redirect_to("/")
  end


  def dc
    @comments = Comment.destroy(params[:id])
    redirect_to ("/")
  end

  def ec
    @comment = Comment.find(params[:id])
  end

  def updatec
      if @comment.update_attributes(params[:comment])
        redirect_to("/")
      else
        redirect_to :actio => "ec"
      end
  end
end

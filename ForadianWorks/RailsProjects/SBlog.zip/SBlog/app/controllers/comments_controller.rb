class CommentsController < ApplicationController


  before_filter :first_rule,
    :only => [:edit, :destroy, :update]
  def first_rule
    @comment = Comment.find(params[:id])
  end

  def index

  end

  def show

  end


  def new
    @comment = Comment.new
  end

  def edit
    ############################
  end

  def create
    @comment = Comment.new(params[:comment])
      if @comment.save
        redirect_to("/")
      else
        redirect_to :action => "new"
      end
  end

  def update
      if @comment.update_attributes(params[:comment])
        redirect_to("/")
      else
        redirect_to :action => "edit"
      end
  end

  def destroy
    @comment.destroy
    redirect_to("/")
  end
end

module TimeslotsHelper

  def findDoctors(department)
    @doctors = Doctor.find(:all, :conditions => {:department_id => department})
    return @doctors
  end
end

module BedHelper
end

module DepartmentsHelper
  def vi(dpid)
    print dpid
    # @department = Department.find()
  end
end

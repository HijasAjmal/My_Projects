class Bed < ActiveRecord::Base
	belongs_to :rooms
end

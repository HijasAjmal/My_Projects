class Timeslot < ActiveRecord::Base
  belongs_to :doctors
end

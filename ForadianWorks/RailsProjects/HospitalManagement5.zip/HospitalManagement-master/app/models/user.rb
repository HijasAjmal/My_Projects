class User < ActiveRecord::Base
  # validates_presence_of :user_name
  belongs_to :user_record, :polymorphic => true, :dependent => :destroy
end

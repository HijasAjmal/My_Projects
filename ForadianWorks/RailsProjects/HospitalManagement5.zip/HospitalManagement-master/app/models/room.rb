class Room < ActiveRecord::Base
  belongs_to :departments
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '9e8cb5749e7e5e71c5dda9558e85d966e594021bf4ae0f262268acb4ea91b85b260a91ea6f53992266122bad96baa63d17ee5f2c39ab1089b1d04d90b7d4c857';

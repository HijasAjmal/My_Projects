# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_SimpleBlog_session',
  :secret      => 'fa4ceee1d83ade296c02015f408f110630ee6431dcb91053adddeba603e402c8410745d477947fbb8e219427c78cd930e2e928b7a1014ac08a19052d5895e772'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store

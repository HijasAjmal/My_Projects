class UserMailer < ActionMailer::Base
  def welcome_email(user)
    recipients    user.email
    from          "hijasajmal@gmail.com"
    subject       "Welcome to My Awesome Site"
    sent_on       Time.now
    body          :user => user, :url => "http://localhost:3000/user/index"
  end

end

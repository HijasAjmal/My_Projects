class Comments < ActiveRecord::Base
end

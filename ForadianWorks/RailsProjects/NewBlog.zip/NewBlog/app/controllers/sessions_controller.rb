class SessionsController < ApplicationController

  def create
    # ...
    session[:current_user_id] = @user.id
    # ...
  end
  def index


  end

  def destroy
    session[:current_user_id] = nil
    redirect_to("/")
  end

  def signin
    print "hello world"
    @user = User.find(:first, :conditions => { :email => params[:email] , :password => params[:password] })
    if @user.nil?
      redirect_to("/")
    else
      #session[:current_user_id] = @user.id
      redirect_to(posts_path)
    end
  end
end

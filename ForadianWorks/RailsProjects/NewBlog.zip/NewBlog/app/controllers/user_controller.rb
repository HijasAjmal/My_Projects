class UserController < ApplicationController

  def index

  end

  def signup
    @user = User.create(:email => params[:email], :password => params[:password])
    redirect_to("/")
  end
end

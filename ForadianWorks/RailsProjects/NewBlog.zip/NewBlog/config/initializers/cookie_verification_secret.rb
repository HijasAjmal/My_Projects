# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'baf7a3104b259a9dcf2ee76ccae58837e7fadf56751031c6d81e59c13ee91ceca6d17ed436073c10260d2a72a69ff6af16d986124de4ab3ac11e2a0b9529c5a4';

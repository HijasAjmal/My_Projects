require 'securerandom'
class DoctorsController < ApplicationController
  def index
    @doctors = Doctors.all
  end

  def new


  end

  def signup
    #if params[:password] != params[:s_password]
    #  redirect_to :controller => :user
    #  flash[:notice] = 'Password different.....'
    #else
    #  @user = Doctors.find(:first, :conditions => { :email => params[:email]})
    #  if @user.nil?
        @user = Users.create()
        @user.user_record = Doctors.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
        :last_name => params[:last_name], :contact_number => params[:contact_number], :email => params[:email], :photo => params[:photo],
      :date_of_birth => params[:date_of_birth], :nationality => params[:nationality], :gender => params[:gender],
    :qualifications => params[:qualifications], :experience => params[:experience], :department_id => params[:department_id])
        @user.save
        print @user.id
        p @user.id
        @u = Users.find(@user.id)
        @d = @u.user_record
        @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex )
        redirect_to :controller => :sessions
    #  else
    #    flash[:notice] = 'Email Already exist in our database.....'
    #    redirect_to :controller => :users
    #  end
    #end
  end


  def show
    @doctors = Doctors.find(params[:id])
  end
end

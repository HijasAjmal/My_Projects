class UsersController < ApplicationController
  def index
    @users = Users.all
  end
  def signup
    @user = Users.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
    :last_name => params[:last_name], :contact_number => params[:contact_number], :email => params[:email])
    @user.update_attributes(:user_name => "A00"+@user.id.to_s, :password => @user.first_name+"@A"+@user.id.to_s, :user_record_type => "Admin", :confirmation_token => SecureRandom.hex)
    redirect_to("/sessions/show")
  end
end

class UsersController < ApplicationController
  def index
    @users = Users.all
  end
  def signup
    @user = Users.create()
    if params[:id] == "3"
      @user.user_record = Patients.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
      :last_name => params[:last_name],:email => params[:email])
      @user.save
      @u = Users.find(@user.id)
      @d = @u.user_record
      @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex )
      UsersMailer.deliver_welcome_email(@d, @u)
      redirect_to("/")
    elsif params[:id] == "2"
      @user.user_record = Doctors.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
      :last_name => params[:last_name], :email => params[:email], :department_id => params[:department_id])
      @user.save
      @u = Users.find(@user.id)
      @d = @u.user_record
      @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex )
      UsersMailer.deliver_welcome_email(@d, @u)
      redirect_to("/doctors/index")
    elsif params[:id] == "1"
      @user = Users.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
        :last_name => params[:last_name], :email => params[:email])
      @user.update_attributes(:user_name => "A00"+@user.id.to_s, :password => @user.first_name+"@A"+@user.id.to_s, :user_record_type => "Admin", :confirmed => 1)
      UsersMailer.deliver_admin_email(@user)
      redirect_to("/sessions/show")
    end
  end
end

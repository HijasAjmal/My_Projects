class PatientsController < ApplicationController

  def index
    @patients = Patients.all
  end

  def new


  end

  def signup
    #if params[:password] != params[:s_password]
    #  redirect_to :controller => :user
    #  flash[:notice] = 'Password different.....'
    #else
    #  @user = Doctors.find(:first, :conditions => { :email => params[:email]})
    #  if @user.nil?
        @user = Users.create()
        @user.user_record = Patients.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
        :last_name => params[:last_name], :contact_number => params[:contact_number], :photo => params[:photo],
      :date_of_birth => params[:date_of_birth], :blood_group => params[:blood_group], :gender => params[:gender],
    :address => params[:address], :email => params[:email])
        @user.save
        @u = Users.find(@user.id)
        @p = @u.user_record
        @u.update_attributes(:user_name => @p.first_name+"@U"+@user.id.to_s, :password => @p.first_name+"@U"+@p.id.to_s)
        redirect_to ("/patients")
    #  else
    #    flash[:notice] = 'Email Already exist in our database.....'
    #    redirect_to :controller => :users
    #  end
    #end
  end


  def details_view_patient
    @p = Users.find(session[:current_user_id])
    @patients = @p.user_record
  end

  def details_view_doctor
    @p = Users.find(:first, :conditions => {:user_record_id => params[:id]})
    @patients = @p.user_record
  end

end

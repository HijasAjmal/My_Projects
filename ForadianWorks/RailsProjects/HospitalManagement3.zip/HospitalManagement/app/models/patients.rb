class Patients < ActiveRecord::Base
end

class Doctors < ActiveRecord::Base
  #validates_presence_of :first_name, :last_name, :date_of_birth, :email, :date_of_birth, :gender, :qualifications, :experience, :doctor_id
  has_many :users, :as => :user_record
end

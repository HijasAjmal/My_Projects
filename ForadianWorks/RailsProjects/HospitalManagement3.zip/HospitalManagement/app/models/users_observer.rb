class UsersObserver < ActiveRecord::Observer

end

class Users < ActiveRecord::Base
  belongs_to :user_record, :polymorphic => true
end

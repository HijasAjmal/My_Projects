class Doctors < ActiveRecord::Base
  has_one :users, :as => :user_record_type
end

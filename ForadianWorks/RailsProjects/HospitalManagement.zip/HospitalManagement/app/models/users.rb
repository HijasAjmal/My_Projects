class Users < ActiveRecord::Base
  belongs_to :user_record_type, :polymorphic => true
end

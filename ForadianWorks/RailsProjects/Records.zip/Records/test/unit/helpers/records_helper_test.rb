require 'test_helper'

class RecordsHelperTest < ActionView::TestCase
end

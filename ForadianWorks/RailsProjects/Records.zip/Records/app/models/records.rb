class Records < ActiveRecord::Base
end

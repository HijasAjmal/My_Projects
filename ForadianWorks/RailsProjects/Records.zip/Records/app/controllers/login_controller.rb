class LoginController < ApplicationController
  def index

  end
  def validate
    @user = Records.find(:first, :conditions => { :email => params[:email] , :password => params[:password] })
    session[:current_user_id] = @user.id
    if @user.nil?
      redirect_to("/")
    else
        redirect_to :controller => 'posts', :action => 'index'
    end
  end
end

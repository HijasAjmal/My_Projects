class LoginController < ApplicationController
  def index

  end
  def validate
    @login = Login.new
    @user = Records.find(:all, :conditions => { :email => params[:email] , :password => params[:password] })
    if @user.empty?
      redirect_to("/")
    else
      redirect_to :controller => 'posts', :action => 'index'
    end
  end

end

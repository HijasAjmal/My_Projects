class RecordsController < ApplicationController
  def index
    @records = Records.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @records }
    end
  end
  def new
    @record = Records.new
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @record }
    end
  end


  def create
    @record = Records.new(params[:records])

    respond_to do |format|
      if @record.save
        format.html { redirect_to("/") }
      else
        format.html { render :action => "new" }
      end
    end
  end


  def show
    @record = Records.find(params[:search])
    respond_to do |format|
      format.html # show.html.erb
    end
  end

  def deleteall
    Records.delete_all()
    format.html { redirect_to("new") }
  end

  def destroy
    @record = Records.find(params[:id])
    @record.destroy

    respond_to do |format|
      format.html { redirect_to("/") }
      format.xml  { head :ok }
    end
  end

  def edit
    @record = Records.find(params[:id])
  end

  def update
    @record = Records.find(params[:id])

    respond_to do |format|
      if @record.update_attributes(params[:records])
        flash[:notice] = 'Post was successfully updated.'
        format.html { redirect_to("/") }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @record.errors,
  	                :status => :unprocessable_entity }
      end
    end
  end
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_Records_session',
  :secret      => 'eaeeb2d58035a0181b30263bca3be41682ac355bac5e33ff1d59e5bbd5b98f9786987f524af0a2b6e1c2824952f76f50934fa046aac805aadf30639263308461'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store

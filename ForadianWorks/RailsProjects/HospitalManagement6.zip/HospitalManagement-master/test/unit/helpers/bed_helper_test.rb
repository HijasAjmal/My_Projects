require 'test_helper'

class BedHelperTest < ActionView::TestCase
end

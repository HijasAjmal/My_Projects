require 'securerandom'
class UsersController < ApplicationController
  def index
    @users = User.all
  end
  def signup
    @user = User.create()

    # sign up for patient
    if params[:id] == "3"
      @user.user_record = Patient.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
      :last_name => params[:last_name],:email => params[:email])
      @user.save
      @u = User.find(@user.id)
      @d = @u.user_record
      @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex(10) )
      UserMailer.deliver_welcome_email(@d, @u)
      redirect_to("/")



      # sign up for doctor
    elsif params[:id] == "2"
      @user.user_record = Doctor.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
      :last_name => params[:last_name], :email => params[:email], :department_id => params[:category][:id])
      @user.save
      @u = User.find(@user.id)
      @d = @u.user_record
      @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex )
      UserMailer.deliver_welcome_email(@d, @u)
      redirect_to("/doctors/index")



      # sign up for admin
    elsif params[:id] == "1"
      @user = User.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
        :last_name => params[:last_name], :email => params[:email])
      @user.update_attributes(:user_name => "A00"+@user.id.to_s, :password => @user.first_name+"@A"+@user.id.to_s, :user_record_type => "Admin", :confirmed => 1, :profile_status => 1)
      UserMailer.deliver_admin_email(@user)
      redirect_to("/sessions/show")
    end
  end
end

















# require 'securerandom'
# class UsersController < ApplicationController
#
#   def index
#     if session[:current_user_id]
#       redirect_to :controller => :sessions, :action => "signin"
#     else
#       @user = User.new
#     end
#   end
#
#   def de
#
#     @user = User.new
#
#   end
#
#
#   def signup
#     # @user = User.create()
#     @user = User.new(params[:user])
#
#     # sign up for patient
#     if params[:id] == "3"
#       @user.user_record = Patient.create(:first_name => @user.first_name, :middle_name => @user.email)
#       @user.save
#       if @user.errors.any?
#           flash[:notice] = 1
#           print "Hello Hijas"
#
#       else
#        @u = User.find(@user.id)
#        @d = @u.user_record
#        @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex(10) )
#        UserMailer.deliver_welcome_email(@d, @u)
#       end
#       redirect_to("/")
#
#
#       # sign up for doctor
#     elsif params[:id] == "2"
#       @user.user_record = Doctor.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
#       :last_name => params[:last_name], :email => params[:email], :department_id => params[:category][:id])
#       @user.save
#       @u = User.find(@user.id)
#       @d = @u.user_record
#       @u.update_attributes(:user_name => @d.first_name+"@U"+@user.id.to_s, :password => @d.first_name+"@U"+@d.id.to_s, :confirmation_token => SecureRandom.hex )
#       UserMailer.deliver_welcome_email(@d, @u)
#       redirect_to("/doctors/index")
#
#
#
#       # sign up for admin
#     elsif params[:id] == "1"
#       @user = User.create(:first_name => params[:first_name], :middle_name => params[:middle_name],
#         :last_name => params[:last_name], :email => params[:email])
#       @user.update_attributes(:user_name => "A00"+@user.id.to_s, :password => @user.first_name+"@A"+@user.id.to_s, :user_record_type => "Admin", :confirmed => 1, :profile_status => 1)
#       UserMailer.deliver_admin_email(@user)
#       redirect_to("/sessions/show")
#     else
#       redirect_to("/")
#     end
#   end
#
#
#
#
#   def create
#     # ...
#     session[:current_user_id] = @user.id
#     # ...
#   end
#
#
#
#
#   def destroy
#     session[:current_user_id] = nil
#     redirect_to :controller => :sessions, :action => "index"
#   end
#
#
#
#
#   def signin
#     if session[:current_user_id]
#       @user = User.find(session[:current_user_id])
#     else
#       @user = User.find(:first, :conditions => { :user_name => params[:user_name] , :password => params[:password]})
#     end
#
#     if @user.nil?
#       # respond_to do |format|
#       #   format.html { render :action => "index" }
#       # end
#       flash[:notice] = 'User Name or Password incorrect.....!'
#
#       redirect_to :controller => :sessions
#     elsif @user.confirmed == 0
#       flash[:notice] = 'User Name or Password incorrect.....!'
#       redirect_to ("/")
#     elsif @user.confirmed == 1 && @user.profile_status == 1
#       session[:current_user_id] = @user.id
#       if @user.user_record_type == "Admin"
#         redirect_to("/sessions/dashboard")
#       elsif @user.user_record_type == "Doctor"
#         redirect_to("/doctors/patient_details_login")
#       elsif @user.user_record_type == "Patient"
#         redirect_to :controller => :patients, :action => :details_view_patient
#       end
#     elsif @user.profile_status != 1 && @user.user_record_type == "Doctor"
#       session[:current_user_id] = @user.id
#       redirect_to("/doctors/doctor_profile_form")
#     elsif @user.profile_status != 1 && @user.user_record_type == "Patient"
#       session[:current_user_id] = @user.id
#       redirect_to("/patients/patient_profile_form")
#     else
#       flash[:notice] = 'Please check your email...!'
#       redirect_to :controller => :sessions
#     end
#   end
#
#
#
#
#   def show
#     @admin = User.find(:all, :conditions =>{:user_record_type => "Admin"})
#   end
#
#
#
#   def confirm
#     @user = User.find(:first, :conditions => { :confirmation_token => params[:id]})
#     if @user.nil?
#       flash[:notice] = 'This link is not valid..!'
#       signin()
#     else
#       @user.update_attributes(:confirmation_token => nil, :confirmed => 1)
#       session[:current_user_id] = @user.id
#
#       signin()
#     end
#   end
#
#
#
#   def forget
#     @user = User.find(:first, :conditions => { :email => params[:email]})
#     if @user.nil?
#       flash[:notice] = 'This email is not exist in our database..!'
#       redirect_to("/")
#     else
#       @user.update_attributes(:remember_token => SecureRandom.hex)
#       UserMailer.deliver_password_email(@user)
#       flash[:notice] = 'Password reset link is in your email..!'
#       redirect_to("/")
#     end
#   end
#
#
#
#
#   def changepwd
#     @user = User.find(:first, :conditions => { :remember_token => params[:id]})
#     if @user.nil?
#       flash[:notice] = 'This link is not valid..!'
#       redirect_to("/")
#     else
#       @user.update_attributes(:password => params[:password], :remember_token => nil)
#       flash[:notice] = 'successfully updated your account password..!'
#       redirect_to("/")
#     end
#   end
#
#
# end

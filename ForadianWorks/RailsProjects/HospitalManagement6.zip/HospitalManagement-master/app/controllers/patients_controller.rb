class PatientsController < ApplicationController

  def index
      @patients = Patient.all
  end

  def new


  end

  def details_view_patient
    @p = User.find(session[:current_user_id])
    @patients = @p.user_record
  end

  def details_view_doctor
    @p = User.find(:first, :conditions => {:user_name => params[:user_id]})
    @patients = @p.user_record
  end

  def details_view
    @p = User.find(:first, :conditions => {:user_name => params[:user_id]})
    @patients = @p.user_record
  end

  def patient_profile_form
    @user = User.find(session[:current_user_id])
    @patient = @user.user_record

  end

  def updateprofile
    @patient = Patient.find(params[:patient])
    @patient.update_attributes(:contact_number => params[:contact_number], :photo => params[:photo],
  :date_of_birth => params[:date_of_birth], :blood_group => params[:blood_group], :gender => params[:gender],
:address => params[:address])
    @user = User.find(:first, :conditions => {:user_record_id  => params[:patient]})
    @user.update_attributes(:profile_status => 1)
    redirect_to ("/patients/show")
  end

  def details_view_admin
    @p = User.find(:first, :conditions => {:user_record_id => params[:id]})
    @patients = @p.user_record
  end
end

class User < ActiveRecord::Base
  # validates_presence_of :first_name, :message => "hello"
  belongs_to :user_record, :polymorphic => true, :dependent => :destroy
end

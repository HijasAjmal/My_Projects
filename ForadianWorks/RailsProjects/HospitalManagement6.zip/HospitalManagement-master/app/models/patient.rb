class Patient < ActiveRecord::Base
  # validates_presence_of :first_name, :message => "hello"
  has_many :users, :as => :user_record

end

require 'Db_configuration'
require 'Table'

class Demo

  #method for the main menu
  def opt
    loop do
      print "\n----------------------------------------------"
      print "\nMenu driven user management system using Ruby\n"
      print "----------------------------------------------\n"
      print "Please select your option\n1. List all users\n2. Add new user\n3. Edit a user\n4. Show a user details\n5. Delete a user\n6. Delete all users\n7. Exit"
      input_choice = gets.to_i
      case input_choice
      when 1
        listAllUsers
      when 2
        addNewUser
      when 3
        editaUser
      when 4
        showaUserDetails
      when 5
        deleteaUser
      when 6
        deleteAllUsers
      when 7
        exit
      else
        puts "Sorry, Wrong Entry.....!"
      end
    end
  end

  #validate the results
  def validate(results)
    if results.nil? || results.empty?
      print "\nDon't Have any records in Database\n\n"
      opt
    end
  end

  #list all the records in database
  def listAllUsers
    results = UserDetails.all
    validate(results)
    table = Terminal::Table.new :headings => ['Id','Name', 'Dob', 'Adrress', 'Contact Number'] do |result|
      results.each do |t|
        result << [t.id, t.full_name, t.dob, t.adrress, t.contact_num]
      end
    end
    puts table

  end

  #add a record into database
  def addNewUser
    puts "Enter the details-------------------------"
    print "Enter the Name::"
    @name = gets.chomp
    print "Enter the Dob (yyyy-mm-dd)::"
    @dob = gets.chomp
    print "Enter the Address::"
    @adrs = gets.chomp
    print "Enter the Contact number::"
    @ph = gets.chomp
    results = UserDetails.new(:full_name => @name, :dob => @dob, :adrress => @adrs, :contact_num => @ph)
    results.save
    puts "User Details added successfully"
  end

  #show details of users
  def showaUserDetails
    print "Enter the id of user::"
    @idn = gets.chomp.to_i
    begin
      results = UserDetails.find(@idn)
      table = Terminal::Table.new :headings => ['Id','Name', 'Dob', 'Adrress', 'Contact Number']
      table << [results.id, results.full_name, results.dob, results.adrress, results.contact_num]
      puts table
    rescue Exception => e
      puts "\nDon't Have any records in Database\n\n"
      opt
    end

  end

  #edit perticular record
  def editaUser
    puts "Enter the details-------------------------"
    puts "Enter the id of Student::"
    @id = gets.chomp.to_i
    newhash = Hash.new
    begin
      results = UserDetails.find(@id)
      newhash = results.attributes
      newhash.delete("id")
    rescue Exception => e
      puts "\nDon't Have any records in Database\n\n"
      opt
    end
    loop do
      print "\n\t1. Name\n\t2. Dob\n\t3. Address\n\t4. Contact_Number\n\t5. Goto Main-Menu\n\t6. Exit"
      edit_choice = gets.to_i
      case edit_choice
      when 1
        print "Enter the Name::"
        newhash['full_name'] = gets.chomp
      when 2
        print "Enter the Dob (yyyy-mm-dd)::"
        newhash['dob'] = gets.chomp
      when 3
        print "Enter the Address::"
        newhash['adrress'] = gets.chomp
      when 4
        print "Enter the Contact number::"
        newhash['contact_num'] = gets.chomp
      when 5
        opt
      else
        exit
      end
      results.update_attributes(newhash)
      puts "User Details ades successfully"
    end
  end


  #delete a record
  def deleteaUser
    puts "Enter the details-------------------------"
    puts "Enter the id of Student::"
    @id = gets.to_i
    results = UserDetails.delete(@id)
    puts "User Details deleted successfully"
  end

  #delete all records from database
  def deleteAllUsers
    UserDetails.delete_all()
    puts "All records are deleted successfully"
  end
end



#call the main method
ob1 = Demo.new
ob1.opt

class UserDetails < ActiveRecord::Base
end

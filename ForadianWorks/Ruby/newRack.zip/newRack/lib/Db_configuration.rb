#Ruby database configuration file
require "rubygems"
require "active_record"
require "yaml"
require "mysql"

class Db_configuration
  def setupConfiguration
    conn = ActiveRecord::Base.establish_connection(YAML.load(File.open("./config/database.yml").read))
    print "Database Connected" if conn != nil
  end
end
class Database < ActiveRecord::Base
end
o = Db_configuration.new
o.setupConfiguration

require "erb"
require 'Db_configuration'
require 'UserDetails'

class HelloWorld
	def call(env)
		@@request = Rack::Request.new(env)
		case @@request.path
		when "/" then Rack::Response.new(render("listall.html.erb"))
		when "/add" then addNewUser
		when "/showaUserDetails" then showaUserDetails
		when "/delete" then delete
		when "/edit" then edit
		when "/update" then update
		when "/deleteall" then deleteall
		else
			Rack::Response.new("Not Found", 404)
		end
	end

	#render function
	def render(template)
		path = File.expand_path("../views/#{template}",__FILE__)
		@@erb = ERB.new(File.read(path)).result(binding)
	end

	#function for deleting all the records
	def deleteall
    UserDetails.delete_all()
		redirect
  end


	#function for deleting a perticular record
	def delete
		@id = "#{@@request.params["id"]}"
    results = UserDetails.delete(@id)
		redirect

	end


	#function to take the id of record need to update
	def edit
    @@idn = "#{@@request.params["id"]}"
		Rack::Response.new(render("edit.html.erb"))
	end

	#function for updating values of record
	def update
    newhash = Hash.new
		print "hello"
      results = UserDetails.find(@@idn)
      newhash = results.attributes
      newhash.delete("id")
      newhash['full_name'] = "#{@@request.params["name"]}" if "#{@@request.params["name"]}".length > 0
      newhash['dob'] = "#{@@request.params["date"]}" if "#{@@request.params["date"]}".length > 0
      newhash['adrress'] = "#{@@request.params["address"]}" if "#{@@request.params["address"]}".length > 0
      newhash['contact_num'] = "#{@@request.params["contactnumber"]}" if "#{@@request.params["contactnumber"]}".length > 0
      results.update_attributes(newhash)
      redirect
  end



#add a record into database
	def addNewUser
		@name = "#{@@request.params["name"]}"
		@dob = "#{@@request.params["date"]}"
		@adrs = "#{@@request.params["address"]}"
		@ph = "#{@@request.params["contactnumber"]}"
		results = UserDetails.new(:full_name => @name, :dob => @dob, :adrress => @adrs, :contact_num => @ph)
		results.save
		redirect
	end

	#function to show a perticular record
	def showaUserDetails
    @idn = "#{@@request.params["search"]}"
		Rack::Response.new(render("index.html.erb"))
	end

	#function for redirect to root
	def redirect
		[ 302, {'Location' =>"/"}, [] ]
	end

end

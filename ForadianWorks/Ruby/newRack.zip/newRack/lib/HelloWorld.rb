require "erb"

class HelloWorld
 def call(env)
   status = 200
    headers = { "Content-Type" => "text/html" }



    #[200, {}, ["Hello Ruby...!"]]
    #Rack::Response.new("Hello Ruby..!")
    @request = Rack::Request.new(env)
    case @request.path
    when "/" then Rack::Response.new(render("index.html.erb"))
    when "/change" then ot(status, headers)
    #Rack::Response.new(request.params["name"])
    else Rack::Response.new("Not Found", 404)
    end
 end

 def ot(status, headers)
   #Rack::Response.new(render("index.html.erb"))
   #body = [""]
   body    = [""]
   [status, headers, body]
 end
 def render(template)
 	path = File.expand_path("../views/#{template}",__FILE__)
	ERB.new(File.read(path)).result(binding)
 end
end

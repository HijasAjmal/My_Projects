class AdmittedRecord < ActiveRecord::Base
  belongs_to :patient
end

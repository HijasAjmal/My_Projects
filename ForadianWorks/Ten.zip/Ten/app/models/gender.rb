class Gender < ActiveRecord::Base
end

class PatientCondition < ActiveRecord::Base
end

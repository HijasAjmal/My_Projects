class Comment < ActiveRecord::Base
	belongs_to :appointments
end

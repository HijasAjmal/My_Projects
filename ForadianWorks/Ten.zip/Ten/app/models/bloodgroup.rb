class Bloodgroup < ActiveRecord::Base
end

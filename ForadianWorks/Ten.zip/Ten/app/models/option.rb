class Option < ActiveRecord::Base
end

require 'test_helper'

class AppointmentHelperTest < ActionView::TestCase
end

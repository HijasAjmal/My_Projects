require 'test_helper'

class AdmittedRecordHelperTest < ActionView::TestCase
end

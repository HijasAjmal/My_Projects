require 'test_helper'

class PhotoHelperTest < ActionView::TestCase
end

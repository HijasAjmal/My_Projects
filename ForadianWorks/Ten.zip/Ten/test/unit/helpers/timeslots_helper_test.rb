require 'test_helper'

class TimeslotsHelperTest < ActionView::TestCase
end

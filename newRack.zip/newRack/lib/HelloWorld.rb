require "erb"
require 'Db_configuration'
require 'UserDetails'

class HelloWorld
	def call(env)
		#status = 200
		#headers = { "Content-Type" => "text/html" }



		#[200, {}, ["Hello Ruby...!"]]
		#Rack::Response.new("Hello Ruby..!")
		@@request = Rack::Request.new(env)

		case @@request.path
		when "/" then Rack::Response.new(render("listall.html.erb"))
			#print "Hijas"
			#when "/change" then Rack::Response.new(request.params["name"])
		when "/add" then addNewUser
		when "/showaUserDetails" then showaUserDetails
		when "/delete" then delete
			#Rack::Response.new(request.params["name"])
		else
			Rack::Response.new("Not Found", 404)
		end



end

	def render(template)
		path = File.expand_path("../views/#{template}",__FILE__)
		@@erb = ERB.new(File.read(path)).result(binding)
	end


	def delete
		print "hello"
		@id = "#{@@request.params["id"]}"
    results = UserDetails.delete(@id)
		Rack::Response.new(render("listall.html.erb"))

	end



#add a record into database
	def addNewUser
		@name = "#{@@request.params["name"]}"
		@dob = "#{@@request.params["date"]}"
		@adrs = "#{@@request.params["address"]}"
		@ph = "#{@@request.params["contactnumber"]}"
		results = UserDetails.new(:full_name => @name, :dob => @dob, :adrress => @adrs, :contact_num => @ph)
		results.save
		Rack::Response.new(render("listall.html.erb"))
		#[status, headers, body]
	end

	def showaUserDetails
    @idn = "#{@@request.params["search"]}"
		Rack::Response.new(render("index.html.erb"))


  end

end

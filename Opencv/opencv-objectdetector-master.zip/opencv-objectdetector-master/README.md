Object Detection using OpenCV and Python

1. 	Face Detector: Detects faces in an image
	Classifier: haarcascade_frontalface_default.xml classifier from OpenCV library


2. 	Face Detector: Detects face/faces in frames(webcam)
	Classifier: haarcascade_frontalface_default.xml classifier from OpenCV library

3. HAAR Cascade trainer: Script to train your haar cascade classifier
